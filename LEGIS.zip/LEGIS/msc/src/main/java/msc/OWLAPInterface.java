package msc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.awt.Panel;
import java.awt.Component;

import javax.swing.Box;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JButton;

import java.awt.FlowLayout;

import javax.swing.BoxLayout;

import java.awt.GridLayout;

import net.miginfocom.swing.MigLayout;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Stream;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormSpecs;
import com.jgoodies.forms.layout.RowSpec;

import javax.swing.JCheckBox;
import javax.swing.JTable;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;

import java.awt.Color;
import java.awt.Font;

import javax.swing.border.LineBorder;

public class OWLAPInterface {

	private JFrame frame;
	private JComboBox olegalact;
	private JTextField ooffender;
	private JTextField ovictim;
	private JTextField ocrimeobject;
	//private JTextField ointention;
	private JComboBox ointention; 

	private JTextArea areaSituacao;
	private JTextArea areaSimulacao;
	private ArrayList<OWLAPISituation> listaSituacao; 

	//aba agente agressor
	private JTextField oage;
	private JCheckBox oisMentallySick;
	private JCheckBox orecurrence;
	private JCheckBox oisMilitia;

	//aba agente v�tima

	private JCheckBox oiswoman;
	private JCheckBox oisvictimpregnat;
	private JCheckBox oisVictimHandicapped;
	private JCheckBox oisVictimWife;
	private JTextField ovictimage;
	private JCheckBox oisDead;

	// aba circunst�ncias

	private JCheckBox ohasTurmoil;
	private JCheckBox oconcealingOtherCrime;
	private JCheckBox ofrivolousReason;
	private JCheckBox ocruelMeanEmployment;
	private JCheckBox oprecludeDefense ;
	private JCheckBox odomesticViolence;
	private JCheckBox ofemaleDiscrimination;
	private JCheckBox oabuseAutority; 
	private JCheckBox oabuseOfPower;
	private JCheckBox ovictimMisfortune;
	private JCheckBox oheatOfPassion;
	private JCheckBox osocialMoralReason;
	private JCheckBox oescapeFromCrimeScene;
	private JCheckBox onoHarmReducation;
	private JCheckBox owithoutImmediateAid;
	private JCheckBox orelativePresence;

	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	private JScrollPane scrollPane_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OWLAPInterface window = new OWLAPInterface();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OWLAPInterface() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1012, 473);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		listaSituacao = new ArrayList<OWLAPISituation>();



		JLabel lblNewLabel = new JLabel("O que aconteceu?");
		lblNewLabel.setBounds(10, 36, 121, 14);

		JLabel lblNewLabel_1 = new JLabel("LEGIS - LEGal analysIS Simulator");
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setBounds(454, 11, 402, 14);

		String[] action = {"","Homic�dio", "Subtra��o", "Agress�o" ,"Participa��o" };
		olegalact = new JComboBox(action);
		olegalact.setBounds(125, 36, 229, 20);
		olegalact.setSelectedIndex(0);
		//olegalact.addActionListener(this);

		JLabel lblQuemRealizou = new JLabel("Quem realizou?");
		lblQuemRealizou.setBounds(10, 70, 121, 14);

		ooffender = new JTextField();
		ooffender.setBounds(125, 67, 229, 20);
		ooffender.setColumns(10);

		JLabel lblContraQuem = new JLabel("Contra Quem?");
		lblContraQuem.setBounds(10, 101, 143, 14);

		ovictim = new JTextField();
		ovictim.setBounds(125, 98, 229, 20);
		ovictim.setColumns(10);

		JLabel lblViolouOQu = new JLabel("Violou o qu\u00EA?");
		lblViolouOQu.setBounds(10, 138, 143, 14);

		ocrimeobject = new JTextField();
		ocrimeobject.setBounds(125, 132, 229, 20);
		ocrimeobject.setColumns(10);

		String[] intention = {null, "Matar", "Roubar", "N�o Intencional", "Inutilizar", "Vantagem Econ�mica" };
		ointention = new JComboBox(intention);
		ointention.setLocation(125, 163);
		ointention.setSize(229, 20);
		ointention.setSelectedIndex(0);
		//ointention.setBounds(125, 163, 229, 20);
		//ointention.setColumns(10);

		JLabel lblEAInteo = new JLabel("E a inten\u00E7\u00E3o?");
		lblEAInteo.setBounds(10, 169, 143, 14);

		JButton btnCarregar = new JButton("Carregar");
		btnCarregar.setBounds(343, 411, 98, 23);

		JButton btnSimular = new JButton("Simular");
		btnSimular.setBounds(498, 411, 94, 23);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 197, 344, 200);
		JPanel pnlUm = new JPanel();
		JPanel pnlDois = new JPanel();
		JPanel pnlTres = new JPanel();
		JPanel pnlQuatro = new JPanel();
		pnlUm.setLayout(null);
		JLabel label = new JLabel("Agente da A��o");
		label.setForeground(Color.BLUE);
		label.setBounds(131, 5, 117, 14);
		pnlUm.add(label);
		pnlDois.setLayout(null);
		JLabel label_1 = new JLabel("Agente com objeto violado");
		label_1.setForeground(Color.BLUE);
		label_1.setBounds(105, 5, 194, 14);
		pnlDois.add(label_1);
		pnlTres.setLayout(null);
		JLabel label_2 = new JLabel("Situa��o");
		label_2.setForeground(Color.BLUE);
		label_2.setBounds(148, 5, 106, 14);
		pnlTres.add(label_2);
		pnlQuatro.setLayout(null);
		JLabel label_3 = new JLabel("Situa��o");
		label_3.setForeground(Color.BLUE);
		label_3.setBounds(149, 5, 115, 14);
		pnlQuatro.add(label_3);


		///////////////////////////
		// Objetos das Abas
		////////////////////////////
		tabbedPane.addTab("Aba 01", null,pnlUm,"Aba 01");

		JLabel lblIdade = new JLabel("Idade:");
		lblIdade.setBounds(10, 33, 46, 14);
		pnlUm.add(lblIdade);

		oage = new JTextField();
		oage.setBounds(50, 30, 86, 20);
		pnlUm.add(oage);
		oage.setColumns(10);
		oage.setText(null);

		oisMentallySick = new JCheckBox("Apresenta algum transtorno mental");
		oisMentallySick.setBounds(10, 67, 252, 23);
		pnlUm.add(oisMentallySick);

		orecurrence = new JCheckBox("J\u00E1 Fichado");
		orecurrence.setBounds(10, 93, 97, 23);
		pnlUm.add(orecurrence);

		oisMilitia = new JCheckBox("Faz parte de Mil\u00EDcia");
		oisMilitia.setBounds(10, 119, 189, 23);
		pnlUm.add(oisMilitia);

		tabbedPane.addTab("Aba 02", null,pnlDois,"Aba 02");

		oiswoman = new JCheckBox("Mulher");
		oiswoman.setBounds(6, 67, 97, 23);
		pnlDois.add(oiswoman);

		oisvictimpregnat = new JCheckBox("Gr\u00E1vida");
		oisvictimpregnat.setBounds(6, 93, 97, 23);
		pnlDois.add(oisvictimpregnat);

		oisVictimHandicapped = new JCheckBox("Possui Defici\u00EAncia");
		oisVictimHandicapped.setBounds(6, 119, 163, 23);
		pnlDois.add(oisVictimHandicapped);

		oisVictimWife = new JCheckBox("Casada com o Agente da A\u00E7\u00E3o");
		oisVictimWife.setBounds(6, 142, 213, 23);
		pnlDois.add(oisVictimWife);

		JLabel lblIdade_1 = new JLabel("Idade:");
		lblIdade_1.setBounds(10, 46, 46, 14);
		pnlDois.add(lblIdade_1);

		ovictimage = new JTextField();
		ovictimage.setBounds(66, 43, 103, 20);
		pnlDois.add(ovictimage);
		ovictimage.setColumns(10);

		oisDead = new JCheckBox("Morto em Decorr\u00EAncia");
		oisDead.setBounds(178, 67, 155, 23);
		pnlDois.add(oisDead);
		tabbedPane.addTab("Aba 03", null,pnlTres,"Aba 03");

		ohasTurmoil = new JCheckBox("Tumulto");
		ohasTurmoil.setBounds(6, 27, 97, 23);
		ohasTurmoil.setToolTipText("Cometido o evento sob a influ�ncia de multid�o em tumulto, se n�o o provocou");
		pnlTres.add(ohasTurmoil);

		oconcealingOtherCrime = new JCheckBox("Esconder outro Crime");
		oconcealingOtherCrime.setBounds(6, 53, 151, 23);
		oconcealingOtherCrime.setToolTipText("Facilitou a oculta��o, impunidade ou vantagem de outro crime");
		pnlTres.add(oconcealingOtherCrime);

		ofrivolousReason = new JCheckBox("Raz\u00E3o F\u00FAtil");
		ofrivolousReason.setBounds(6, 79, 97, 23);
		ofrivolousReason.setToolTipText("cometido o evento por motivo f�til ou torpe");
		pnlTres.add(ofrivolousReason);

		ocruelMeanEmployment = new JCheckBox("Meios Cru\u00E9is");
		ocruelMeanEmployment.setBounds(6, 105, 137, 23);
		ocruelMeanEmployment.setToolTipText("Veneno, fogo, explosivo, tortura ou outro meio cruel");
		pnlTres.add(ocruelMeanEmployment);

		oprecludeDefense = new JCheckBox("Defesa Reduzida");
		oprecludeDefense.setBounds(6, 131, 137, 23);
		oprecludeDefense.setToolTipText("Trai��o, emboscada ou outro meio que dificultou a defesa do ofendido");
		pnlTres.add(oprecludeDefense);

		odomesticViolence = new JCheckBox("Viol\u00EAncia Dom\u00E9stica");
		odomesticViolence.setBounds(159, 26, 174, 23);
		odomesticViolence.setToolTipText("Viol�ncia Dom�stica e familiar");
		pnlTres.add(odomesticViolence);

		ofemaleDiscrimination = new JCheckBox("Discrimina\u00E7\u00E3o da Mulher");
		ofemaleDiscrimination.setBounds(159, 53, 174, 23);
		ofemaleDiscrimination.setToolTipText("Menosprezo ou discrimina��o � condi��o de mulher");
		pnlTres.add(ofemaleDiscrimination);

		oabuseAutority = new JCheckBox("Abuso de Autoridade");
		oabuseAutority.setBounds(159, 79, 174, 23);
		oabuseAutority.setToolTipText("Com Abuso de Autoridade");
		pnlTres.add(oabuseAutority);

		oabuseOfPower = new JCheckBox("Abuso de Poder");
		oabuseOfPower.setBounds(159, 105, 118, 23);
		oabuseOfPower.setToolTipText("Com Abuso de Poder");
		pnlTres.add(oabuseOfPower);

		ovictimMisfortune = new JCheckBox("Tribula\u00E7\u00E3o da V\u00EDtima");
		ovictimMisfortune.setBounds(159, 131, 174, 23);
		ovictimMisfortune.setToolTipText("Inc�ndio, Inunda��o, Calamidade P�blica ou qualquer desgra�a do ofendido");
		pnlTres.add(ovictimMisfortune);

		tabbedPane.addTab("Aba 04", null,pnlQuatro,"Aba 04");

		oheatOfPassion = new JCheckBox("Calor do Momento");
		oheatOfPassion.setBounds(6, 27, 130, 23);
		oheatOfPassion.setToolTipText("Influ�ncia de violenta emo��o");
		pnlQuatro.add(oheatOfPassion);

		osocialMoralReason = new JCheckBox("Valor Social/Moral");
		osocialMoralReason.setBounds(6, 53, 143, 23);
		osocialMoralReason.setToolTipText("Cometido o evento por motivo de relevante valor social ou moral");
		pnlQuatro.add(osocialMoralReason);

		oescapeFromCrimeScene = new JCheckBox("Fuga da Cena");
		oescapeFromCrimeScene.setBounds(6, 79, 143, 23);
		oescapeFromCrimeScene.setToolTipText("Fuga para evitar pris�o em flagrante");
		pnlQuatro.add(oescapeFromCrimeScene);

		onoHarmReducation = new JCheckBox("Sem Redu\u00E7\u00E3o de Risco");
		onoHarmReducation.setBounds(149, 27, 170, 23);
		onoHarmReducation.setToolTipText("N�o procurou diminuir as consequ�ncias do ato");
		pnlQuatro.add(onoHarmReducation);

		owithoutImmediateAid = new JCheckBox("Sem Aux\u00EDlio Imediato");
		owithoutImmediateAid.setBounds(149, 53, 170, 23);
		owithoutImmediateAid.setToolTipText("N�o prestou aux�lio imediato");
		pnlQuatro.add(owithoutImmediateAid);

		orelativePresence = new JCheckBox("Presen\u00E7a de Familiar");
		orelativePresence.setBounds(149, 79, 184, 23);
		orelativePresence.setToolTipText("Cometido na presen�a de fam�lia do ofendido");
		pnlQuatro.add(orelativePresence);

		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(lblNewLabel);
		frame.getContentPane().add(lblViolouOQu);
		frame.getContentPane().add(lblEAInteo);
		frame.getContentPane().add(lblQuemRealizou);
		frame.getContentPane().add(lblContraQuem);
		frame.getContentPane().add(ointention);
		frame.getContentPane().add(ovictim);
		frame.getContentPane().add(olegalact);
		frame.getContentPane().add(ooffender);
		frame.getContentPane().add(ocrimeobject);
		frame.getContentPane().add(btnCarregar);
		frame.getContentPane().add(btnSimular);
		frame.getContentPane().add(tabbedPane);
		//frame.getContentPane().add(areaSimulacao);
		frame.getContentPane().add(lblNewLabel_1);
		//add(tabbedPane);
		//setVisible(true);


		JButton btnSair = new JButton("Sair");
		btnSair.setBounds(646, 411, 87, 23);
		frame.getContentPane().add(btnSair);

		scrollPane = new JScrollPane();
		scrollPane.setSize(622, -192);
		scrollPane.setLocation(364, 395);
		frame.getContentPane().add(scrollPane);

		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(364, 214, 620, 183);
		frame.getContentPane().add(scrollPane_2);


		areaSimulacao = new JTextArea();
		areaSimulacao.setFont(new Font("Monospaced", Font.ITALIC, 13));
		areaSimulacao.setForeground(Color.BLUE);
		scrollPane_2.setViewportView(areaSimulacao);
		areaSimulacao.setVisible(true);


		areaSituacao = new JTextArea();
		areaSituacao.setEditable(false);
		areaSituacao.setBounds(364, 36, 622, 147);
		frame.getContentPane().add(areaSituacao);

		//bot�o de carregar


		btnCarregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {          
				// OWLAPISituation situacaoCrime = new OWLAPISituation(ooffender.getText(), ovictim.getText(), ointention.getSelectedItem().toString(),
				//		   olegalact.getSelectedItem().toString(), ocrimeobject.getText(), oage.getText(), ovictimage.getText(), oisMentallySick.isSelected(), 
				//		   oiswoman.isSelected(), oisVictimWife.isSelected(), oisvictimpregnat.isSelected(),oisVictimHandicapped.isSelected(),
				//		   ohasTurmoil.isSelected(), oconcealingOtherCrime.isSelected(), ocruelMeanEmployment.isSelected(),
				//		   ofrivolousReason.isSelected(), oprecludeDefense.isSelected(), odomesticViolence.isSelected(), ofemaleDiscrimination.isSelected(),
				//		   oabuseAutority.isSelected(), oabuseOfPower.isSelected(), ovictimMisfortune.isSelected(), orecurrence.isSelected(), oheatOfPassion.isSelected(),
				//		   osocialMoralReason.isSelected(), oescapeFromCrimeScene.isSelected(), onoHarmReducation.isSelected(), 
				//		   owithoutImmediateAid.isSelected(), orelativePresence.isSelected());
				OWLAPISituation situacaoCrime = new OWLAPISituation(ooffender.getText(), ovictim.getText(), ointention.getSelectedItem().toString(),
						olegalact.getSelectedItem().toString(), ocrimeobject.getText());

				//adiciona o novo objeto
				listaSituacao.add(situacaoCrime);
				//adiciona visualmente na tela
				atualizaSituacao();
			}    
		});

		btnSimular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {          
				//   if (listaSituacao.isEmpty()){
				//	   
				//   }
				//   else{

				//  }

				carregaSituacao();

			}    
		});

		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {  
				System.exit(1);	
			} 
		});
	}

	//atualiza a tabela com os dados do array list
	public void atualizaSituacao(){
		this.areaSituacao.setText(null);
		Iterator<OWLAPISituation> it = this.listaSituacao.iterator();
		while (it.hasNext()){

			OWLAPISituation element = it.next();
			this.areaSituacao.append(element.offender + " " + element.legalact + " " + element.crimeObject + " " +element.victim + " " + element.intention +"\n" );
		}
	}

	@SuppressWarnings("deprecation")
	public boolean carregaSituacao(){



		OWLAPIConstant constant = new OWLAPIConstant();
		OWLAPIFirst obj = new OWLAPIFirst();
		Stream<OWLOntology> importsClosure;
		//Carrega Ontologia

		//
		if ((this.olegalact.getSelectedItem().toString().equals("Subtra��o")) || (this.olegalact.getSelectedItem().toString().equals("Agress�o"))){
			importsClosure =  obj.loadingOntoProperty();
		}
		else if ((this.olegalact.getSelectedItem().toString().equals("Homic�dio")) && (this.ointention.getSelectedItem().toString().equals("Roubar"))){
			importsClosure =  obj.loadingOntoProperty();
		}
		else{
			importsClosure =  obj.loadingOntoMurder();
		}

		this.areaSimulacao.setText(null);


		//iterar sobre os elementos: a princ�pio, s� alterando a a��o e o objeto do crime
		Iterator<OWLAPISituation> it = this.listaSituacao.iterator();
		while (it.hasNext()){

			OWLAPISituation newSituation = it.next();	
			this.olegalact.setSelectedItem(newSituation.legalact);	
			this.ointention.setSelectedItem(newSituation.intention);
			this.ocrimeobject.setText(newSituation.crimeObject);


			//Instancia a A��o

			if(this.olegalact.getSelectedItem().toString().equals("Homic�dio")){
				obj.classAssertion("murder" + "_" + this.ooffender.getText() + "_" + this.ovictim.getText(), constant.MURDER);
			}
			else if (this.olegalact.getSelectedItem().toString().equals("Subtra��o")){
				obj.classAssertion("subtraction" + "_" + this.ooffender.getText() + "_" + this.ovictim.getText(), constant.SUBTRACTION);
			}
			else if (this.olegalact.getSelectedItem().toString().equals("Agress�o")){
				obj.classAssertion("aggression" + "_" + this.ooffender.getText() + "_" + this.ovictim.getText(), constant.AGGRESSION);
				//obj.classAssertion("subtraction" + "_" + this.ooffender.getText() + "_" + this.ovictim.getText(), constant.SUBTRACTION);
			}

			////////////////////////////////////////////////////////////////////////////////
			//Instancia os Agentes
			obj.classAssertion(this.ooffender.getText(), constant.ACTIVEAGENT);
			obj.classAssertion(this.ovictim.getText(), constant.PASSIVEPERSON);

			////////////////////////////////////////////////
			//Definindo caracter�sticas do agente agressor
			///////////////////////////////////////////////
			if (this.oage.getText().isEmpty()){

				this.areaSimulacao.setText(null);
				this.areaSimulacao.setText("!!! Informe idade, e se o agente cometeu \n /participou do evento tem "
						+ "\n algum transtorno mental, \n ou se j� � fichado. ");
				return false;
			}
			Integer activeAgentAge;
			try{
				activeAgentAge = Integer.valueOf(this.oage.getText().toString());
			}
			catch(NumberFormatException e){
				this.areaSimulacao.setText("!!! Informe uma idade para o agente quem realizou o evento");
				return false;
			}
			if (activeAgentAge >= 18){
				obj.classAssertion(this.ooffender.getText(), constant.ADULT);									
			}
			else {
				obj.classAssertion(this.ooffender.getText(), constant.UNDERAGE);					
			}

			if (activeAgentAge >= 70){
				obj.classAssertion(this.ooffender.getText(), constant.AGENTOVERSEVENTY);									
			}

			if (activeAgentAge <= 21){
				obj.classAssertion(this.ooffender.getText(), constant.AGENTUNDERTWENTYONE);									
			}

			if (this.oisMentallySick.isSelected())
				obj.classAssertion(this.ooffender.getText(), constant.MENTALLYSICK);
			else
				obj.classAssertion(this.ooffender.getText(), constant.MENTALLYHEATHY);

			if (this.oisMilitia.isSelected())
				obj.classAssertion(this.ooffender.getText(), constant.MILITIA);

			//Linkando o agente � a��o
			obj.objectPropertyAssertion(this.ooffender.getText(), getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()), constant.ISAUTHOROF);
			////////////////////////////////////////////////////////////////////////////////

			////////////////////////////////////////////////
			//Definindo caracter�sticas do agente ofendido
			///////////////////////////////////////////////

			if (this.oiswoman.isSelected())
				obj.classAssertion(this.ovictim.getText(), constant.WOMAN);
			if (this.oisvictimpregnat.isSelected())
				obj.classAssertion(this.ovictim.getText(), constant.PREGNANT);
			if (this.oisVictimHandicapped.isSelected())
				obj.classAssertion(this.ovictim.getText(), constant.HANDICAPPED);
			if (this.oisDead.isSelected()){
				obj.classAssertion(this.ovictim.getText(), constant.DECEASED);
			}

			Integer victimAgentAge;
			try{
				victimAgentAge = Integer.valueOf(this.oage.getText().toString());
				if (victimAgentAge <=14)
					obj.classAssertion(this.ovictim.getText(), constant.AGENTUNDERFOURTEEN);
				else if (victimAgentAge >=60)
					obj.classAssertion(this.ovictim.getText(), constant.AGENTOVERSIXTY);

			}
			catch(NumberFormatException e){
				this.areaSimulacao.setText(this.areaSimulacao.getText() + "\n !!! Idade do agente ofendido n�o informada.");
				return false;
			}

			//Instancia a Inten��o	
			//{"","Matar", "Roubar", "N�o Intencional", "Inutilizar", "Vantagem Econ�mica" }
			String intentionConverted = null;
			if (ointention.getSelectedItem().toString().equals("Matar")){
				intentionConverted = "death";

			}else if (ointention.getSelectedItem().toString().equals("N�o Intencional")){
				intentionConverted = "malPractice";		

			}else if (ointention.getSelectedItem().toString().equals("Roubar")){
				intentionConverted = "stealing";	

			}else if (ointention.getSelectedItem().toString().equals("Inutilizar")){
				intentionConverted = "makeUnusable";	

			}
			else if (ointention.getSelectedItem().toString().equals("Vantagem Econ�mica")){
				intentionConverted = "economicAdvantage";			
			}

			if (!intentionConverted.equals(null)){
				obj.classAssertion(intentionConverted, constant.INTENTION);
			}



			//Instancia a Situa��o		
			obj.classAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), constant.SITUATION);

			//Instancia o Evento


			//Verificar como definir o objeto do crime

			if(this.olegalact.getSelectedItem().toString().equals("Homic�dio")){
				obj.classAssertion(this.ocrimeobject.getText(), constant.LIFE);
			}
			else if (this.olegalact.getSelectedItem().toString().equals("Subtra��o")){
				obj.classAssertion(this.ocrimeobject.getText(), constant.CHATTELOBJECT);
			}
			else if (this.olegalact.getSelectedItem().toString().equals("Agress�o")){
				if (this.ocrimeobject.getText().equals("Psicol�gica")){
					obj.classAssertion(this.ocrimeobject.getText(), constant.PSYCHOLOGICAL);
				}
				else if (this.ocrimeobject.getText().equals("Corpo")){
					obj.classAssertion(this.ocrimeobject.getText(), constant.PHYSICALBODY);
					if (this.oisDead.isSelected()){
						obj.classAssertion("LifeOf" + this.ovictim.getText(), constant.LIFE);
						obj.objectPropertyAssertion(getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()),"LifeOf" + this.ovictim.getText(), constant.VIOLATES);
					}

				}

			}

			obj.objectPropertyAssertion(getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()),this.ocrimeobject.getText(), constant.VIOLATES);
			//obj.objectPropertyAssertion(this.ocrimeobject.getText(), this.ovictim.getText(),constant.ISASSOCIATEDTO);




			//Instancia as Propriedades

			obj.objectPropertyAssertion(this.ovictim.getText(), this.ocrimeobject.getText(), constant.HASVIOLATEDOBJECT);

			//vai buscar se a inten��o foi instanciada no combobox
			if (!intentionConverted.equals(null)){
				obj.objectPropertyAssertion(getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()), intentionConverted, constant.CAUSEDBY);
			}


			obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), this.ovictim.getText(), constant.HASENDURANT);
			obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()), constant.HASCRIMINALACT);


			//Instancia as Circunst�ncias

			//obj.classAssertion("circunstance" + "_" + this.ooffender.getText() + "_" + this.ovictim.getText(), constant.CIRCUMSTANCE);

			if (this.orecurrence.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.RECURRENCE, constant.RECURRENCE);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.RECURRENCE, constant.HASCIRCUMSTANCE);
			}
			if(this.ohasTurmoil.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.TURMOIL, constant.TURMOIL);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.TURMOIL, constant.HASCIRCUMSTANCE);
			}	
			if(this.oconcealingOtherCrime.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.CONCEALINGOTHERCRIME, constant.CONCEALINGOTHERCRIME);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.CONCEALINGOTHERCRIME, constant.HASCIRCUMSTANCE);
			}
			if(this.ofrivolousReason.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.FRIVOLOUSREASON, constant.FRIVOLOUSREASON);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.FRIVOLOUSREASON, constant.HASCIRCUMSTANCE);
			}
			if(this.ocruelMeanEmployment.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.CRUELMEANSEMPLOYMENT, constant.CRUELMEANSEMPLOYMENT);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.CRUELMEANSEMPLOYMENT, constant.HASCIRCUMSTANCE);
			}
			if(this.oprecludeDefense.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.PRECLUDEDEFENSE, constant.PRECLUDEDEFENSE);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.PRECLUDEDEFENSE, constant.HASCIRCUMSTANCE);
			}
			if(this.odomesticViolence.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.DOMESTICVIOLENCE, constant.DOMESTICVIOLENCE);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.DOMESTICVIOLENCE, constant.HASCIRCUMSTANCE);
			}
			if(this.ofemaleDiscrimination.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.FEMALEDISCRIMINATION, constant.FEMALEDISCRIMINATION);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.FEMALEDISCRIMINATION, constant.HASCIRCUMSTANCE);
			}
			if(this.oabuseAutority.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.ABUSEOFAUTHORITY, constant.ABUSEOFAUTHORITY);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.ABUSEOFAUTHORITY, constant.HASCIRCUMSTANCE);
			}
			if(this.oabuseOfPower.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.ABUSEOFPOWER, constant.ABUSEOFPOWER);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.ABUSEOFPOWER, constant.HASCIRCUMSTANCE);
			}
			if(this.ovictimMisfortune.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.AGENTMISFORTUNE, constant.AGENTMISFORTUNE);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.AGENTMISFORTUNE, constant.HASCIRCUMSTANCE);
			}
			if(this.oheatOfPassion.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.HEATOFPASSION, constant.HEATOFPASSION);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.HEATOFPASSION, constant.HASCIRCUMSTANCE);
			}
			if(this.osocialMoralReason.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.SOCIALMORALREASON, constant.SOCIALMORALREASON);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.SOCIALMORALREASON, constant.HASCIRCUMSTANCE);
			}
			if(this.oescapeFromCrimeScene.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.ESCAPEFROMCRIMESCENE, constant.ESCAPEFROMCRIMESCENE);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.ESCAPEFROMCRIMESCENE, constant.HASCIRCUMSTANCE);
			}
			if(this.onoHarmReducation.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.NOHARMREDUCATION, constant.NOHARMREDUCATION);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.NOHARMREDUCATION, constant.HASCIRCUMSTANCE);
			}
			if(this.owithoutImmediateAid.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.WITHOUTIMMEDIATEAID, constant.WITHOUTIMMEDIATEAID);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.WITHOUTIMMEDIATEAID, constant.HASCIRCUMSTANCE);
			}
			if(this.orelativePresence.isSelected()){
				obj.classAssertion("circunstance" + "_" + constant.RELATIVEPRESENCE, constant.RELATIVEPRESENCE);
				obj.objectPropertyAssertion(getSituation(this.ooffender.getText(), this.ovictim.getText()), "circunstance" + "_" + constant.RELATIVEPRESENCE, constant.HASCIRCUMSTANCE);
			}
		}//fim do while

		//Salva a Ontologia Criada
		obj.saveNewOntology();

		JFrame frameOption = new JFrame("Simulal��o");
		int resposta = JOptionPane.showConfirmDialog(frameOption, "Continua com a entrada de situa��es?","Simula��o", JOptionPane.YES_NO_OPTION);

		if (resposta == JOptionPane.YES_OPTION)
			return true;


		//Chama o Raciocinador		
		obj.callReasoner();

		//****************************************
		//Printando Resultado
		
		Iterator<OWLAPISituation> iterator = this.listaSituacao.iterator();
		while (iterator.hasNext()){

			OWLAPISituation element = iterator.next();
			this.olegalact.setSelectedItem(element.legalact);

		//Tipo do Crime (e se � crime)
		NodeSet<OWLClass> listClasses = obj.classifyInferredType(getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()));
		this.areaSimulacao.append("\n SOBRE O EVENTO " + getAction(this.olegalact.getSelectedItem().toString(), this.ooffender.getText(), this.ovictim.getText()) + ": \n");		
		for (OWLClass c : listClasses.getFlattened())        {
			this.areaSimulacao.append(c.getIRI().getFragment());
			this.areaSimulacao.append("\n");
		}}

		//Tipo do Autor
		NodeSet<OWLClass> listClassesOffender = obj.classifyInferredType(this.ooffender.getText());
		this.areaSimulacao.append("\n SOBRE O AGRESSOR " + this.ooffender.getText() + ": \n");		
		for (OWLClass cOffender : listClassesOffender.getFlattened())        {
			this.areaSimulacao.append(cOffender.getIRI().getFragment());
			this.areaSimulacao.append("\n");
		}

		//Tipo do Ofendido
		NodeSet<OWLClass> listClassesVictim = obj.classifyInferredType(this.ovictim.getText());
		this.areaSimulacao.append("\n SOBRE A V�TIMA " + this.ooffender.getText() + ": \n");		
		for (OWLClass cVictim : listClassesVictim.getFlattened())        {
			this.areaSimulacao.append(cVictim.getIRI().getFragment());
			this.areaSimulacao.append("\n");
		}

		//Sobre a situa��o
		NodeSet<OWLClass> listClassesSituation= obj.classifyInferredType(getSituation(this.ooffender.getText(), this.ovictim.getText()));
		this.areaSimulacao.append("\n SOBRE A SITUA��O " + getSituation(this.ooffender.getText(), this.ovictim.getText()) + ": \n");		
		for (OWLClass cSituation : listClassesSituation.getFlattened())        {
			this.areaSimulacao.append(cSituation.getIRI().getFragment());
			this.areaSimulacao.append("\n");
		}				

		//Sobre o artigo

		NodeSet<OWLNamedIndividual> listArticles = obj.getForbiddenArticle(getSituation(this.ooffender.getText(), this.ovictim.getText()));
		this.areaSimulacao.append("\n H� ARTIGO(S) VIOLADO(S) ? \n " );		
		for (OWLNamedIndividual cArticle : listArticles.getFlattened())        {
			this.areaSimulacao.append(cArticle.getIRI().getFragment());
			this.areaSimulacao.append("\n PUNI��ES ? " );		
			this.areaSimulacao.append(obj.getPunishment(cArticle));
			this.areaSimulacao.append("\n");
		}

		this.areaSimulacao.append("\n");

		// Resolvendo conflito

		this.areaSimulacao.append("\n H� CONFLITO ? " );		
		this.areaSimulacao.append(obj.getConflictSolving(listArticles));


		return true;

	}

	public String getSituation(String offender, String victim){
		return "situation_" + offender + "_" + victim;
	}

	public String getAction(String legalact, String offender, String victim){
		if (legalact.equals("Homic�dio")){
			return "murder" + "_" + offender + "_" + victim;
		}
		else if (legalact.equals("Subtra��o")){
			return "subtraction" + "_" + offender + "_" + victim;
		}
		else if (legalact.equals("Agress�o")){
			return "aggression" + "_" + offender + "_" + victim;
		}
		return null;

	}
}
