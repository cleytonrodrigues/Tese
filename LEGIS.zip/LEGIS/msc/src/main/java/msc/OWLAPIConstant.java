package msc;

public class OWLAPIConstant {
	
	public final String ACTIVEAGENT = "ActiveAgent";
	public final String ADULT = "Adult";
	public final String AGENTUNDERFOURTEEN = "AgentUnderFourteen";
	public final String AGENTUNDERTWENTYONE = "AgentUnderTwentyOne";
	public final String AGENTOVERSIXTY = "AgentOverSixty";
	public final String AGENTOVERSEVENTY = "AgentOverSeventy";
	public final String AGGRESSION = "Aggression";
	public final String PASSIVEPERSON = "PassivePerson";
	public final String AGENT = "Agent";
	public final String CIRCUMSTANCE = "Circumstance";
	public final String CHATTELOBJECT = "ChattelObject";
	public final String DEATH = "death";
	public final String DECEASED = "Deceased";
	public final String HANDICAPPED = "Handicapped";
	public final String LIFE = "Life";
	public final String INTENTION = "Intention";
	public final String LEGALRULE = "LegalRule";
	public final String MENTALLYHEATHY = "MentallyHealthy";
	public final String MENTALLYSICK = "MentallySick";
	public final String MILITIA = "MilitiaMan";
	public final String MORAL = "Moral";
	public final String MURDER = "Murder";
	public final String PREGNANT = "Pregant";
	public final String PHYSICALBODY = "PhysicalBody";
	public final String PSYCHOLOGICAL = "Psychological";
	public final String PUNISHMENTACT = "PunishmentAct";
	public final String SITUATION = "Situation";
	public final String SUBTRACTION = "Subtraction";
	public final String UNDERAGE = "Underage";
	public final String WOMAN = "Woman";
	
	public final String ISAUTHOROF = "isAuthorOf";
	public final String ISASSOCIATEDTO = "isAssociatedTo";
	public final String ISDISALLOWEDBY = "isDisallowedBy";
	public final String CAUSEDBY = "causedBy";
	public final String HASCIRCUMSTANCE = "hasCircumstance";
	public final String HASENDURANT = "hasEndurant";
	public final String HASCRIMINALACT = "hasCriminalAct";
	public final String HASPUNISHMENT = "hasPunishment";
	public final String HASVIOLATEDOBJECT = "hasViolatedObject";
	public final String PERFORMANCEOF = "performanceOf";
	public final String VIOLATES = "violates";
	
	// Circumstances
	public final String ABUSEOFAUTHORITY = "AbuseOfAuthority";
	public final String ABUSEOFPOWER = "AbuseOfPower";
	public final String AGENTMISFORTUNE = "AgentMisfortune";
	public final String CONCEALINGOTHERCRIME = "ConcealingOtherCrime";
	public final String CRUELMEANSEMPLOYMENT = "CruelMeansEmployment";
	public final String DAMAGEREPAIR = "DamageRepair";
	public final String DOMESTICVIOLENCE = "DomesticViolence";
	public final String ESCAPEFROMCRIMESCENE = "EscapeFromCrimeScene";
	public final String FEMALEDISCRIMINATION = "FemaleDiscrimination";
	public final String FRIVOLOUSREASON = "FrivolousReason";
	public final String HEATOFPASSION = "HeatOfPassion";
	public final String NOHARMREDUCATION = "NoHarmReducation";
	public final String PRECLUDEDEFENSE = "PrecludeDefense";
	public final String RECURRENCE = "Recurrence";
	public final String RELATIVE = "Relative";
	public final String RELATIVEPRESENCE = "RelativePresence";
	public final String RESISTIBLEDURESS = "ResistibleDuress";
	public final String SOCIALMORALREASON = "SocialMoralReason";
	public final String UNFAMILIAIRTYOFLAW = " UnfamiliairtyofLaw";
	public final String TURMOIL = "Turmoil";
	public final String VOLUNTARYCONFESSION = "VoluntaryConfession";
	public final String WITHOUTIMMEDIATEAID = "WithoutImmediateAid";

}
