package msc;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class OWLAPISituation {

	public String offender;
	public String victim;
	public String intention;
	public String legalact;
	public String crimeObject;
	public String crimeInstrument;
	
	//about the offender
	public String age;
	public boolean isMentallySick;
	public boolean hasDutyToAct;
	public boolean hasAbility;
	public boolean hasSpecificDutyToAct;
	
	//about the victim
	public String victimAge;
	public boolean isWoman;
	public boolean isVictimWife;
	public boolean isVictimPregnant;
	public boolean isVictimHandicapped;
	
	//about the situation
	public boolean hasTurmoil;	
	public boolean concealingOtherCrime;
	public boolean cruelMeanEmployment;
	public boolean frivolousReason;
	public boolean precludeDefense;	
	public boolean domesticViolence;
	public boolean femaleDiscrimination;
	public boolean abuseAutority;
	public boolean abuseOfPower;
	public boolean victimMisfortune;
	public boolean recurrence;
	public boolean heatOfPassion;
	public boolean socialMoralReason;
	public boolean escapeFromCrimeScene;
	public boolean noHarmReducation;
	public boolean withoutImmediateAid;
	public boolean relativePresence;

	public OWLAPISituation(String offender, String victim, String intention, String legalAct, String crimeObject) {
		this.offender = offender;
		this.victim = victim;
		this.intention = intention;
		this.legalact = legalAct;
		this.crimeObject = crimeObject;		
	}
	
	public OWLAPISituation(String offender, String victim, String intention,
			String legalact, String crimeObject, 
			String age, String victimAge, boolean isMentallySick, boolean isWoman,
			boolean isVictimWife, boolean isVictimPregnant,
			boolean isVictimHandicapped, boolean hasTurmoil,
			boolean concealingOtherCrime, boolean cruelMeanEmployment,
			boolean frivolousReason, boolean precludeDefense,
			boolean domesticViolence, boolean femaleDiscrimination,
			boolean abuseAutority, boolean abuseOfPower,
			boolean victimMisfortune, boolean recurrence,
			boolean heatOfPassion, boolean socialMoralReason,
			boolean escapeFromCrimeScene, boolean noHarmReducation,
			boolean withoutImmediateAid, boolean relativePresence) {
		super();
		this.offender = offender;
		this.victim = victim;
		this.intention = intention;
		this.legalact = legalact;
		this.crimeObject = crimeObject;
		this.crimeInstrument = crimeInstrument;
		this.age = age;
		this.victimAge = victimAge;
		this.isMentallySick = isMentallySick;
		this.hasDutyToAct = hasDutyToAct;
		this.hasAbility = hasAbility;
		this.hasSpecificDutyToAct = hasSpecificDutyToAct;
		this.isWoman = isWoman;
		this.isVictimWife = isVictimWife;
		this.isVictimPregnant = isVictimPregnant;
		this.isVictimHandicapped = isVictimHandicapped;
		this.hasTurmoil = hasTurmoil;
		this.concealingOtherCrime = concealingOtherCrime;
		this.cruelMeanEmployment = cruelMeanEmployment;
		this.frivolousReason = frivolousReason;
		this.precludeDefense = precludeDefense;
		this.domesticViolence = domesticViolence;
		this.femaleDiscrimination = femaleDiscrimination;
		this.abuseAutority = abuseAutority;
		this.abuseOfPower = abuseOfPower;
		this.victimMisfortune = victimMisfortune;
		this.recurrence = recurrence;
		this.heatOfPassion = heatOfPassion;
		this.socialMoralReason = socialMoralReason;
		this.escapeFromCrimeScene = escapeFromCrimeScene;
		this.noHarmReducation = noHarmReducation;
		this.withoutImmediateAid = withoutImmediateAid;
		this.relativePresence = relativePresence;
	}





public String getOffender() {
		return offender;
	}

	public void setOffender(String offender) {
		this.offender = offender;
	}

	public String getVictim() {
		return victim;
	}

	public void setVictim(String victim) {
		this.victim = victim;
	}

	public String getIntention() {
		return intention;
	}

	public void setIntention(String intention) {
		this.intention = intention;
	}

	public String getLegalact() {
		return legalact;
	}

	public void setLegalact(String legalact) {
		this.legalact = legalact;
	}

	public String getCrimeObject() {
		return crimeObject;
	}

	public void setCrimeObject(String crimeObject) {
		this.crimeObject = crimeObject;
	}

	public String getCrimeInstrument() {
		return crimeInstrument;
	}

	public void setCrimeInstrument(String crimeInstrument) {
		this.crimeInstrument = crimeInstrument;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
	
	public String getVictimAge() {
		return victimAge;
	}

	public void setVictimAge(String victimAge) {
		this.victimAge = victimAge;
	}


	public boolean isMentallySick() {
		return isMentallySick;
	}

	public void setMentallySick(boolean isMentallySick) {
		this.isMentallySick = isMentallySick;
	}

	public boolean isHasTurmoil() {
		return hasTurmoil;
	}

	public void setHasTurmoil(boolean hasTurmoil) {
		this.hasTurmoil = hasTurmoil;
	}

	public boolean isHasDutyToAct() {
		return hasDutyToAct;
	}

	public void setHasDutyToAct(boolean hasDutyToAct) {
		this.hasDutyToAct = hasDutyToAct;
	}

	public boolean isHasAbility() {
		return hasAbility;
	}

	public void setHasAbility(boolean hasAbility) {
		this.hasAbility = hasAbility;
	}

	public boolean isHasSpecificDutyToAct() {
		return hasSpecificDutyToAct;
	}

	public void setHasSpecificDutyToAct(boolean hasSpecificDutyToAct) {
		this.hasSpecificDutyToAct = hasSpecificDutyToAct;
	}

	public boolean isConcealingOtherCrime() {
		return concealingOtherCrime;
	}

	public void setConcealingOtherCrime(boolean concealingOtherCrime) {
		this.concealingOtherCrime = concealingOtherCrime;
	}

	public boolean isCruelMeanEmployment() {
		return cruelMeanEmployment;
	}

	public void setCruelMeanEmployment(boolean cruelMeanEmployment) {
		this.cruelMeanEmployment = cruelMeanEmployment;
	}

	public boolean isFrivolousReason() {
		return frivolousReason;
	}

	public void setFrivolousReason(boolean frivolousReason) {
		this.frivolousReason = frivolousReason;
	}

	public boolean isPrecludeDefense() {
		return precludeDefense;
	}

	public void setPrecludeDefense(boolean precludeDefense) {
		this.precludeDefense = precludeDefense;
	}

	public boolean isWoman() {
		return isWoman;
	}

	public void setWoman(boolean isWoman) {
		this.isWoman = isWoman;
	}

	public boolean isDomesticViolence() {
		return domesticViolence;
	}

	public void setDomesticViolence(boolean domesticViolence) {
		this.domesticViolence = domesticViolence;
	}

	public boolean isFemaleDiscrimination() {
		return femaleDiscrimination;
	}

	public void setFemaleDiscrimination(boolean femaleDiscrimination) {
		this.femaleDiscrimination = femaleDiscrimination;
	}

	public boolean isVictimWife() {
		return isVictimWife;
	}

	public void setVictimWife(boolean isVictimWife) {
		this.isVictimWife = isVictimWife;
	}

    public boolean isAbuseAutority() {
		return abuseAutority;
	}

	public void setAbuseAutority(boolean abuseAutority) {
		this.abuseAutority = abuseAutority;
	}

	public boolean isAbuseOfPower() {
		return abuseOfPower;
	}

	public void setAbuseOfPower(boolean abuseOfPower) {
		this.abuseOfPower = abuseOfPower;
	}

	public boolean isVictimMisfortune() {
		return victimMisfortune;
	}

	public void setVictimMisfortune(boolean victimMisfortune) {
		this.victimMisfortune = victimMisfortune;
	}

	public boolean isRecurrence() {
		return recurrence;
	}

	public void setRecurrence(boolean recurrence) {
		this.recurrence = recurrence;
	}

	public boolean isHeatOfPassion() {
		return heatOfPassion;
	}

	public void setHeatOfPassion(boolean heatOfPassion) {
		this.heatOfPassion = heatOfPassion;
	}

	public boolean isSocialMoralReason() {
		return socialMoralReason;
	}

	public void setSocialMoralReason(boolean socialMoralReason) {
		this.socialMoralReason = socialMoralReason;
	}

	public boolean isEscapeFromCrimeScene() {
		return escapeFromCrimeScene;
	}

	public void setEscapeFromCrimeScene(boolean escapeFromCrimeScene) {
		this.escapeFromCrimeScene = escapeFromCrimeScene;
	}

	public boolean isNoHarmReducation() {
		return noHarmReducation;
	}

	public void setNoHarmReducation(boolean noHarmReducation) {
		this.noHarmReducation = noHarmReducation;
	}

	public boolean isWithoutImmediateAid() {
		return withoutImmediateAid;
	}

	public void setWithoutImmediateAid(boolean withoutImmediateAid) {
		this.withoutImmediateAid = withoutImmediateAid;
	}

	public boolean isVictimPregnant() {
		return isVictimPregnant;
	}

	public void setVictimPregnant(boolean isVictimPregnant) {
		this.isVictimPregnant = isVictimPregnant;
	}

	public boolean isVictimHandicapped() {
		return isVictimHandicapped;
	}

	public void setVictimHandicapped(boolean isVictimHandicapped) {
		this.isVictimHandicapped = isVictimHandicapped;
	}
	
	public String printSituation(OWLAPISituation s){
		return s.offender + " " + s.legalact + " " + s.crimeObject + " " +s.victim + " " + s.intention; 
	
	}

}
