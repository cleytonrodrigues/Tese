package msc;

import java.awt.EventQueue;
import java.util.stream.Stream;

import javax.swing.JFrame;

import org.semanticweb.owlapi.model.OWLOntology;

public class OWLAPIPrincipal {
	
	public static void main(String[] args){
		//OWLAPIFirst obj = new OWLAPIFirst();
		//Stream<OWLOntology> importsClosure =  obj.loadingOntoMurder();
		//String instance = "bob";
		//String classConcept = "NaturalPerson";
		//String instance1 = "777";
		//String classConcept1 = "CPF";
		//String objectProperty = "hasRegister";
		
		//obj.classAssertion(instance, classConcept);
		//obj.classAssertion(instance1, classConcept1);
		//obj.objectPropertyAssertion(instance, instance1, objectProperty);
		//obj.saveNewOntology();
		
		//obj.callReasoner(importsClosure);
		
 }

}
