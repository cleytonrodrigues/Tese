package msc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Stream;

import org.semanticweb.HermiT.ReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.FunctionalSyntaxDocumentFormat;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import com.github.jsonldjava.core.RDFDataset.IRI;

public class OWLAPIFirst {
	
	public OWLOntology onto;
	public OWLOntology onto2;
	
	public Stream<OWLOntology> loadingOntoMurder(){
		
		 OWLOntologyManager man = OWLManager.createOWLOntologyManager();
		 File file = new File("C:\\Cleyton\\PhD\\Tese\\Novo\\Chatbot\\LEGIS\\msc\\src\\main\\resources\\OntoCrime.owl");
		 File file2 = new File("C:\\Cleyton\\PhD\\Tese\\Novo\\Chatbot\\LEGIS\\msc\\src\\main\\resources\\OntoMurder.owl");
		 
		 
		 try {
			 
			this.onto = man.loadOntologyFromOntologyDocument(file);
		    this.onto2 = man.loadOntologyFromOntologyDocument(file2);
			
			Stream<OWLOntology> importsClosure = man.importsClosure(onto2);
			return importsClosure;
			//Iterator<OWLOntology> itr = importsClosure.iterator();
			//while (itr.hasNext()){
			//	 System.out.println(itr.next());
			// }
		 }catch(OWLOntologyCreationException e){
			 e.printStackTrace();
		 }
		 return null;
		 
	}
	
	public Stream<OWLOntology> loadingOntoProperty(){
		
		OWLOntologyManager man = OWLManager.createOWLOntologyManager();
		 File file = new File("C:\\Cleyton\\PhD\\Tese\\Novo\\Chatbot\\LEGIS\\msc\\src\\main\\resources\\OntoCrime.owl");
		 File file2 = new File("C:\\Cleyton\\PhD\\Tese\\Novo\\Chatbot\\LEGIS\\msc\\src\\main\\resources\\OntoProperty.owl");
		 
		 
		 try {
			 
			this.onto = man.loadOntologyFromOntologyDocument(file);
			this.onto2 = man.loadOntologyFromOntologyDocument(file2);
					
			Stream<OWLOntology> importsClosure = man.importsClosure(onto2);
			return importsClosure;
			//Iterator<OWLOntology> itr = importsClosure.iterator();
			//while (itr.hasNext()){
			//	 System.out.println(itr.next());
			 //}
		 }catch(OWLOntologyCreationException e){
			 e.printStackTrace();
		 }
		return null;
		
	}
	
	//Associar inst�ncias atrav�s de um OWLObjectProperty
	public void objectPropertyAssertion(String individualDomain, String individualRange, String property){
		
		OWLDataFactory df = this.onto2.getOWLOntologyManager().getOWLDataFactory();
		OWLIndividual ontoIndividualD = df.getOWLNamedIndividual(getLocalOntologyIRI(this.onto2) + '#' + individualDomain);
		OWLIndividual ontoIndividualR = df.getOWLNamedIndividual(getLocalOntologyIRI(this.onto2) + '#' + individualRange);
		OWLObjectProperty ontoProperty = df.getOWLObjectProperty(getSpecificIri(property) + property);
				
		OWLObjectPropertyAssertionAxiom da = df.getOWLObjectPropertyAssertionAxiom(ontoProperty, ontoIndividualD, ontoIndividualR);
		this.onto2.add(da);
		
	}
	
	//Criar uma Inst�ncia para um OWLCLass
		public void classAssertion(String individual, String concept){
			
			OWLDataFactory df = this.onto2.getOWLOntologyManager().getOWLDataFactory();
			OWLIndividual ontoIndividual = df.getOWLNamedIndividual(getLocalOntologyIRI(this.onto2) + '#' + individual);
			
			OWLClass ontoClass = df.getOWLClass(getSpecificIri(concept) + concept);
			OWLClassAssertionAxiom da = df.getOWLClassAssertionAxiom(ontoClass, ontoIndividual);
			this.onto2.add(da);
		}
	
	//retornar IRI da Ontologia
	public String getLocalOntologyIRI(OWLOntology onto){
		return onto.getOntologyID().getOntologyIRI().get().toString();
		
	}
	
	@SuppressWarnings("deprecation")
	public String getSpecificIri(String concept){
		
		for (Iterator<OWLClass> iterator = this.onto2.getClassesInSignature().iterator(); iterator
				.hasNext();) {
			OWLClass cls = iterator.next();
			
			if (cls.getIRI().getFragment().equals(concept)){
				//System.out.println("\n " + concept + " onto2 " + cls.getIRI().getNamespace());
				return cls.getIRI().getNamespace();
			}
		}
		//System.out.println("\n " + concept + " onto " + getLocalOntologyIRI(this.onto));
		return getLocalOntologyIRI(this.onto) + "#";
	}
	
	//chamando o reasoner
		public void callReasoner(){
			OWLDataFactory df = onto2.getOWLOntologyManager().getOWLDataFactory();
			OWLReasonerFactory rf = new ReasonerFactory();
			OWLReasoner reasoner = rf.createNonBufferingReasoner(onto2);
			reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
			boolean consistent = reasoner.isConsistent();
	        System.out.println("Consistent: " + consistent);
	        System.out.println("\n");
	        //System.out.println(getLocalOntologyIRI(this.onto2) + '#' + concept);
	        //reasoner.getSuperClasses(df.getOWLClass(getLocalOntologyIRI(this.onto2) + '#' + "FelonyMurder"), false).forEach(System.out::println);
	        System.out.println("\n !!!!!!!!!!! ");
	        getSpecificIri("Woman");
		}
	
	//salvar a ontologia em outro documento
	public void saveNewOntology(){
		
		File fileout = new File("C:\\Cleyton\\PhD\\Tese\\Novo\\Chatbot\\LEGIS\\msc\\src\\main\\resources\\OntoCrimeChanged.owl");
		try {
			//Outros formatos s�o permitidos como o FunctionalSyntaxDocumentFormat()
			//que estava originalmente na chamada
			this.onto.getOWLOntologyManager().saveOntology(this.onto2, new org.semanticweb.owlapi.formats.OWLXMLDocumentFormat(), 
					new FileOutputStream(fileout));
		} catch (OWLOntologyStorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	public NodeSet<OWLClass> classifyInferredType(String individual){
				
				OWLDataFactory df = onto2.getOWLOntologyManager().getOWLDataFactory();
				OWLReasonerFactory rf = new ReasonerFactory();
				OWLReasoner reasoner = rf.createNonBufferingReasoner(onto2);
				reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
				
				OWLNamedIndividual ontoIndividual = df.getOWLNamedIndividual(getLocalOntologyIRI(this.onto2) + '#' + individual);
				
				return reasoner.getTypes(ontoIndividual);	
		
				
	}
	
	@SuppressWarnings("deprecation")
	public NodeSet<OWLNamedIndividual>  getForbiddenArticle(String individual){
		OWLDataFactory df = onto2.getOWLOntologyManager().getOWLDataFactory();
		OWLReasonerFactory rf = new ReasonerFactory();
		OWLReasoner reasoner = rf.createNonBufferingReasoner(onto2);
		reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
		
		OWLNamedIndividual ontoIndividual = df.getOWLNamedIndividual(getLocalOntologyIRI(this.onto2) + '#' + individual);
		//OWLObjectPropertyExpression owlOp = df.getOWLObjectProperty(getLocalOntologyIRI(this.onto) + '#' + "isDisallowedBy");
		return reasoner.getObjectPropertyValues(ontoIndividual, df.getOWLObjectProperty(getLocalOntologyIRI(this.onto) + '#' + "isDisallowedBy"));
						
     }
	
	public String getPunishment (OWLNamedIndividual cArticle) {
		OWLDataFactory df = onto2.getOWLOntologyManager().getOWLDataFactory();
		OWLReasonerFactory rf = new ReasonerFactory();
		OWLReasoner reasoner = rf.createNonBufferingReasoner(onto2);
		reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
		
		String finalString= "";
					
		NodeSet<OWLNamedIndividual> listPunishment = reasoner.getObjectPropertyValues(cArticle, df.getOWLObjectProperty(getLocalOntologyIRI(this.onto) + '#' + "hasPunishment"));
		for (OWLNamedIndividual cPunishment : listPunishment.getFlattened())        {
			finalString = finalString + "\n" + cPunishment.getIRI().getFragment();
		}
		
		return finalString;
	}
	
	public String getConflictSolving (NodeSet<OWLNamedIndividual> listArticles) {
		OWLDataFactory df = onto2.getOWLOntologyManager().getOWLDataFactory();
		OWLReasonerFactory rf = new ReasonerFactory();
		OWLReasoner reasoner = rf.createNonBufferingReasoner(onto2);
		reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);
		
		String finalString= "";
		
			
		for (OWLNamedIndividual cArticle : listArticles.getFlattened()){
			NodeSet<OWLNamedIndividual> listGeneralArticles =  reasoner.getObjectPropertyValues(cArticle, df.getOWLObjectProperty(getLocalOntologyIRI(this.onto) + '#' + "specializes"));
			for (OWLNamedIndividual cGeneralArticle : listGeneralArticles.getFlattened())        {
				if (listArticles.containsEntity(cGeneralArticle)){
					finalString = finalString + "\n" + cArticle.getIRI().getFragment() + " especializa " + cGeneralArticle.getIRI().getFragment();
				}
				
			}
		}
		return finalString;
	}
	

}
