% Autor:
% Data:

:- module(ocip,[oc/5, sub/2, facts/0, resposta/1]).
:- use_module(library(chr)).

:- chr_constraint oc/5, sub/2, facts/0, csp/0.

:- dynamic resposta/1.




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BANNER                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- nl.
:- format("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n",[]).
:- format("%                    __   __     __                             %\n",[]).
:- format("%                   |  | |    | |__|                            %\n",[]).
:- format("%                   |__| |__  | |     Version 2.0               %\n",[]).
:- format("%                                                               %\n",[]).
:- format("%            OntoClean Implementation in Prolog                 %\n",[]).
:- format("% OCIP version 1.0, Copyright (C) 2016                          %\n",[]).
:- format("% This is free software, and you are welcome to redistribute it.%\n",[]).
:- format("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n\n",[]).

%facts <=> oc(agente,ar,ni,nu,d), oc(organizacao,r,o, u,d), oc(pessoaNatural,r,o, u,nd),
%           oc(pessoaPassiva,ar,i, u,d),oc(pessoaAtiva,ar,i, u,d),
%           oc(pessoaImputavel,ar,i, u,nd),oc(pessoaInimputavel,nr,i, u,nd), sub(agente,organizacao),
%           sub(agente,pessoaNatural), sub(pessoaNatural,pessoaPassiva),
%           sub(pessoaNatural,pessoaAtiva),sub(pessoaNatural,pessoaImputavel),sub(pessoaNatural,pessoaInimputavel),
%           oc(comportamento,r,o,u,d), oc(involuntario,r,i,u,d), oc(voluntario,r,i,u,d),
%           sub(comportamento,involuntario),sub(comportamento,voluntario),
%           oc(conduta,r,i,u,d), oc(acao,r,i,u,d), oc(omissao,r,i,u,d),
%           oc(condutaPermitida,nr,i,u,d),oc(condutaProibida,nr,i,u,d),
%           oc(condutaComCulpabilidade,nr,i,u,d),  oc(condutaComPericulosidade,nr,i,u,d),oc(condutaConflitante,nr,i,u,d),
%           oc(conflitoDeontico,nr,i,u,d),oc(infracaoPenal,nr,i,u,d),
%           oc(Contravencao,nr,i,u,d), oc(Crime,nr,i,u,d),
%           sub(voluntario,conduta), sub(conduta,acao), sub(conduta,omissao),
%           sub(conduta,condutaPermitida),sub(conduta,condutaProibida), sub(condutaPermitida,conflitoDeontico),
%           sub(condutaProibida,condutaComCulpabilidade),  sub(condutaProibida,condutaComPericulosidade),
%           sub(condutaProibida,condutaConflitante), sub(condutaProibida,conflitoDeontico),
%           sub(condutaProibida,infracaoPenal), sub(infracaoPenal,Contravencao), sub(infracaoPenal,Crime).

%facts <=> oc(agente,r,ni,nu,nd), oc(organizacao,r,o, u,nd), oc(pessoaNatural,r,o, u,nd),
%           oc(pessoaPassiva,ar,i, u,d), oc(pessoaViva,r,i, u,nd),oc(pessoaAtiva,ar,i, u,d),
%           oc(pessoaImputavel,ar,i, u,nd),oc(pessoaInimputavel,nr,i, u,nd), sub(agente,organizacao),
%           sub(agente,pessoaNatural), sub(pessoaNatural,pessoaPassiva),sub(pessoaNatural,pessoaViva),
%           sub(pessoaViva,pessoaAtiva),sub(pessoaViva,pessoaImputavel),sub(pessoaViva,pessoaInimputavel),
%           oc(comportamento,r,o,nu,d), oc(involuntario,r,i,nu,d), oc(voluntario,r,i,nu,d),
%           sub(comportamento,involuntario),sub(comportamento,voluntario),
%           oc(conduta,r,i,nu,d), oc(acao,nr,ni,u,nd), oc(omissao,r,ni,nu,d),
%           oc(condutaPermitida,nr,i,nu,d),oc(condutaProibida,nr,i,nu,d),
%           oc(condutaComCulpabilidade,nr,i,nu,d),  oc(condutaComPericulosidade,nr,i,nu,d),oc(condutaConflitante,nr,i,nu,d),
%           oc(conflitoDeontico,nr,i,nu,d),oc(infracaoPenal,nr,i,nu,d),
%           oc(Contravencao,nr,i,nu,d), oc(Crime,nr,i,nu,d),
%           sub(voluntario,conduta), sub(conduta,acao), sub(conduta,omissao),
%           sub(conduta,condutaPermitida),sub(conduta,condutaProibida), sub(condutaPermitida,conflitoDeontico),
%           sub(condutaProibida,condutaComCulpabilidade),  sub(condutaProibida,condutaComPericulosidade),
%           sub(condutaProibida,condutaConflitante), sub(condutaProibida,conflitoDeontico),
%           sub(condutaProibida,infracaoPenal), sub(infracaoPenal,Contravencao), sub(infracaoPenal,Crime).

%facts<=>   oc(entity,r,ni,nu,nd), oc(location,r,o,au,nd),oc(matter,r,o,au,nd), oc(red,nr,ni,nu,nd), oc(agent,ar,ni,nu,d), oc(group,r,o,au,nd),
%            oc(physicalObject,r,o,u,nd), oc(livingBeing,r,o,u,nd), oc(groupPeople,r,i,au,nd), oc(fruit,r,o,u,nd), oc(food,ar,i,au,d),
%            oc(animal,r,o,u,nd), oc(socialEntity,r,ni,u,nd), oc(legalAgent,ar,i,nu,d), oc(apple,r,o,u,nd), oc(country,ar,i,u,nd),
%            oc(redApple,ar,i,u,nd), oc(caterpillar,ar,i,u,nd), oc(butterfly,ar,i,u,nd), oc(vertebrate,r,i,u,nd), oc(organization,r,o,u,nd),
%            oc(person,r,o,u,nd), sub(entity, location), sub(entity, matter), sub(entity,red), sub(entity,agent),
%            sub(entity, group), sub(location,country), sub(matter,physicalObject), sub(matter,food), sub(matter,livingBeing),
%            sub(entity, livingBeing), sub(physicalObject, fruit), sub(physicalObject,animal), sub(red,redApple),
%            sub(agent, animal), sub(agent, legalAgent), sub(agent,socialEntity), sub(livingBeing, animal),
%            sub(group,groupPeople), sub(groupPeople,socialEntity), sub(groupPeople,organization), sub(fruit, apple),
%            sub(food, apple), sub(food, caterpillar), sub(apple, redApple), sub(socialEntity, organization),
%            sub(legalAgent, organization), sub(legalAgent, person), sub(legalAgent, country), sub(animal, caterpillar),
%            sub(animal, butterfly), sub(animal, vertebrate), sub(vertebrate, person).

%facts<=>   oc(entity,r,ni,nu,nd), oc(location,r,o,nu,nd),oc(matter,r,o,au,nd), oc(group,r,o,au,nd),
%            oc(physicalObject,r,o,u,nd), oc(livingBeing,r,o,u,nd), oc(groupPeople,r,i,au,nd), oc(fruit,r,o,u,nd),
%            oc(animal,r,o,u,nd), oc(socialEntity,r,ni,u,nd), oc(apple,r,o,u,nd), oc(country,r,o,u,d),
%            oc(region,r,i,nu,nd), oc(lepidopteran,r,o,u,nd), oc(caterpillar,ar,i,u,nd), oc(butterfly,ar,i,u,nd),
%            oc(vertebrate,r,i,u,nd), oc(organization,r,o,u,nd), oc(person,r,o,u,nd),
%            sub(entity, location), sub(entity, matter), sub(entity, physicalObject), sub(entity, livingBeing),
%            sub(entity,socialEntity), sub(entity, group), sub(location,region), sub(physicalObject, fruit),
%            sub(fruit, apple), sub(livingBeing, animal), sub(animal, lepidopteran), sub(animal, vertebrate),
%            sub(lepidopteran, caterpillar), sub(lepidopteran, butterfly), sub(vertebrate, person),
%            sub(socialEntity, organization), sub(socialEntity, country), sub(group,groupPeople).

%facts<=>   oc(entity,r,ni,nu,nd), oc(location,r,o,nu,nd),oc(matter,r,o,au,nd), oc(group,r,o,au,nd),
%            oc(physicalObject,r,o,u,nd), oc(livingBeing,r,o,u,nd), oc(groupPeople,r,i,au,nd), oc(fruit,r, i, u, nd),
%            oc(animal,AR,AI,AU,AD), oc(socialEntity,r,ni,u,nd), oc(apple,r,o,u,nd), oc(country,r,o,u,d),
%            oc(region,r,i,nu,nd), oc(lepidopteran,r,o,u,nd), oc(caterpillar,ar,i,u,nd), oc(butterfly,ar,i,u,nd),
%            oc(vertebrate,VR,VI,VU,VD), oc(organization,r,o,u,nd), oc(person,r,o,u,nd),
%            sub(entity, location), sub(entity, matter), sub(entity, physicalObject), sub(entity, livingBeing),
%            sub(entity,socialEntity), sub(entity, group), sub(location,region), sub(physicalObject, fruit),
%            sub(fruit, apple), sub(livingBeing, animal), sub(animal, lepidopteran), sub(animal, vertebrate),
%            sub(lepidopteran, caterpillar), sub(lepidopteran, butterfly), sub(vertebrate, person),
%            sub(socialEntity, organization), sub(socialEntity, country), sub(group,groupPeople).

facts <=> oc(sloppygiuseppe,nr,_,_,_),
oc(sloppygiuseppe,_,i,_,_),
oc(sloppygiuseppe,_,_,u,_),
oc(sloppygiuseppe,_,_,_,nd),
oc(spiciness,r,_,_,_),
oc(spiciness,_,ni,_,_),
oc(spiciness,_,_,u,_),
oc(spiciness,_,_,_,nd),
oc(margherita,ar,_,_,_),
oc(margherita,_,ni,_,_),
oc(margherita,_,_,au,_),
oc(margherita,_,_,_,d),
oc(peperonatatopping,ar,_,_,_),
oc(peperonatatopping,_,i,_,_),
oc(peperonatatopping,_,_,u,_),
oc(peperonatatopping,_,_,_,d),
oc(mixedseafoodtopping,ar,_,_,_),
oc(mixedseafoodtopping,_,ni,_,_),
oc(mixedseafoodtopping,_,_,au,_),
oc(mixedseafoodtopping,_,_,_,d),
oc(tomatotopping,nr,_,_,_),
oc(tomatotopping,_,i,_,_),
oc(tomatotopping,_,_,u,_),
oc(tomatotopping,_,_,_,nd),
oc(deeppanbase,ar,_,_,_),
oc(deeppanbase,_,ni,_,_),
oc(deeppanbase,_,_,u,_),
oc(deeppanbase,_,_,_,d),
oc(sultanatopping,ar,_,_,_),
oc(sultanatopping,_,ni,_,_),
oc(sultanatopping,_,_,u,_),
oc(sultanatopping,_,_,_,d),
oc(meattopping,ar,_,_,_),
oc(meattopping,_,ni,_,_),
oc(meattopping,_,_,au,_),
oc(meattopping,_,_,_,d),
oc(american,r,_,_,_),
oc(american,_,o,_,_),
oc(american,_,_,au,_),
oc(american,_,_,_,nd),
oc(thinandcrispybase,r,_,_,_),
oc(thinandcrispybase,_,i,_,_),
oc(thinandcrispybase,_,_,u,_),
oc(thinandcrispybase,_,_,_,nd),
oc(namedpizza,ar,_,_,_),
oc(namedpizza,_,ni,_,_),
oc(namedpizza,_,_,nu,_),
oc(namedpizza,_,_,_,nd),
oc(mushroom,ar,_,_,_),
oc(mushroom,_,ni,_,_),
oc(mushroom,_,_,u,_),
oc(mushroom,_,_,_,nd),
oc(hotspicedbeeftopping,r,_,_,_),
oc(hotspicedbeeftopping,_,o,_,_),
oc(hotspicedbeeftopping,_,_,nu,_),
oc(hotspicedbeeftopping,_,_,_,d),
oc(country,r,_,_,_),
oc(country,_,i,_,_),
oc(country,_,_,au,_),
oc(country,_,_,_,d),
oc(icecream,ar,_,_,_),
oc(icecream,_,o,_,_),
oc(icecream,_,_,au,_),
oc(icecream,_,_,_,nd),
oc(soho,r,_,_,_),
oc(soho,_,i,_,_),
oc(soho,_,_,u,_),
oc(soho,_,_,_,nd),
oc(sundriedtomatotopping,r,_,_,_),
oc(sundriedtomatotopping,_,o,_,_),
oc(sundriedtomatotopping,_,_,u,_),
oc(sundriedtomatotopping,_,_,_,d),
oc(spicytopping,r,_,_,_),
oc(spicytopping,_,i,_,_),
oc(spicytopping,_,_,nu,_),
oc(spicytopping,_,_,_,d),
oc(prawnstopping,ar,_,_,_),
oc(prawnstopping,_,ni,_,_),
oc(prawnstopping,_,_,nu,_),
oc(prawnstopping,_,_,_,nd),
oc(fishtopping,ar,_,_,_),
oc(fishtopping,_,o,_,_),
oc(fishtopping,_,_,nu,_),
oc(fishtopping,_,_,_,d),
oc(spicypizzaequivalent,r,_,_,_),
oc(spicypizzaequivalent,_,i,_,_),
oc(spicypizzaequivalent,_,_,u,_),
oc(spicypizzaequivalent,_,_,_,nd),
oc(nonvegetarianpizza,nr,_,_,_),
oc(nonvegetarianpizza,_,i,_,_),
oc(nonvegetarianpizza,_,_,nu,_),
oc(nonvegetarianpizza,_,_,_,nd),
oc(mozzarellatopping,ar,_,_,_),
oc(mozzarellatopping,_,o,_,_),
oc(mozzarellatopping,_,_,au,_),
oc(mozzarellatopping,_,_,_,d),
oc(garlictopping,ar,_,_,_),
oc(garlictopping,_,i,_,_),
oc(garlictopping,_,_,u,_),
oc(garlictopping,_,_,_,nd),
oc(gorgonzolatopping,ar,_,_,_),
oc(gorgonzolatopping,_,i,_,_),
oc(gorgonzolatopping,_,_,au,_),
oc(gorgonzolatopping,_,_,_,d),
oc(cheesetopping,nr,_,_,_),
oc(cheesetopping,_,ni,_,_),
oc(cheesetopping,_,_,au,_),
oc(cheesetopping,_,_,_,d),
oc(cheeseyvegetabletopping,nr,_,_,_),
oc(cheeseyvegetabletopping,_,ni,_,_),
oc(cheeseyvegetabletopping,_,_,nu,_),
oc(cheeseyvegetabletopping,_,_,_,nd),
oc(siciliana,r,_,_,_),
oc(siciliana,_,ni,_,_),
oc(siciliana,_,_,au,_),
oc(siciliana,_,_,_,nd),
oc(pizza,ar,_,_,_),
oc(pizza,_,ni,_,_),
oc(pizza,_,_,u,_),
oc(pizza,_,_,_,nd),
oc(parmense,nr,_,_,_),
oc(parmense,_,ni,_,_),
oc(parmense,_,_,nu,_),
oc(parmense,_,_,_,nd),
oc(spinachtopping,ar,_,_,_),
oc(spinachtopping,_,o,_,_),
oc(spinachtopping,_,_,nu,_),
oc(spinachtopping,_,_,_,nd),
oc(rosemarytopping,r,_,_,_),
oc(rosemarytopping,_,o,_,_),
oc(rosemarytopping,_,_,u,_),
oc(rosemarytopping,_,_,_,nd),
oc(unclosedpizza,r,_,_,_),
oc(unclosedpizza,_,i,_,_),
oc(unclosedpizza,_,_,au,_),
oc(unclosedpizza,_,_,_,nd),
oc(sweetpeppertopping,ar,_,_,_),
oc(sweetpeppertopping,_,o,_,_),
oc(sweetpeppertopping,_,_,nu,_),
oc(sweetpeppertopping,_,_,_,d),
oc(petitpoistopping,ar,_,_,_),
oc(petitpoistopping,_,ni,_,_),
oc(petitpoistopping,_,_,au,_),
oc(petitpoistopping,_,_,_,d),
oc(mild,nr,_,_,_),
oc(mild,_,o,_,_),
oc(mild,_,_,u,_),
oc(mild,_,_,_,d),
oc(mushroomtopping,r,_,_,_),
oc(mushroomtopping,_,ni,_,_),
oc(mushroomtopping,_,_,u,_),
oc(mushroomtopping,_,_,_,nd),
oc(chickentopping,r,_,_,_),
oc(chickentopping,_,o,_,_),
oc(chickentopping,_,_,au,_),
oc(chickentopping,_,_,_,d),
oc(princecarlo,ar,_,_,_),
oc(princecarlo,_,o,_,_),
oc(princecarlo,_,_,au,_),
oc(princecarlo,_,_,_,d),
oc(peperonisausagetopping,ar,_,_,_),
oc(peperonisausagetopping,_,o,_,_),
oc(peperonisausagetopping,_,_,nu,_),
oc(peperonisausagetopping,_,_,_,nd),
oc(pizzatopping,nr,_,_,_),
oc(pizzatopping,_,o,_,_),
oc(pizzatopping,_,_,u,_),
oc(pizzatopping,_,_,_,d),
oc(vegetarianpizzaequivalent1,ar,_,_,_),
oc(vegetarianpizzaequivalent1,_,i,_,_),
oc(vegetarianpizzaequivalent1,_,_,nu,_),
oc(vegetarianpizzaequivalent1,_,_,_,d),
oc(tobascopeppersauce,r,_,_,_),
oc(tobascopeppersauce,_,i,_,_),
oc(tobascopeppersauce,_,_,nu,_),
oc(tobascopeppersauce,_,_,_,d),
oc(artichoketopping,ar,_,_,_),
oc(artichoketopping,_,ni,_,_),
oc(artichoketopping,_,_,nu,_),
oc(artichoketopping,_,_,_,d),
oc(medium,r,_,_,_),
oc(medium,_,ni,_,_),
oc(medium,_,_,nu,_),
oc(medium,_,_,_,d),
oc(nuttopping,ar,_,_,_),
oc(nuttopping,_,ni,_,_),
oc(nuttopping,_,_,nu,_),
oc(nuttopping,_,_,_,nd),
oc(napoletana,nr,_,_,_),
oc(napoletana,_,i,_,_),
oc(napoletana,_,_,u,_),
oc(napoletana,_,_,_,d),
oc(leektopping,r,_,_,_),
oc(leektopping,_,i,_,_),
oc(leektopping,_,_,nu,_),
oc(leektopping,_,_,_,d),
oc(hotgreenpeppertopping,ar,_,_,_),
oc(hotgreenpeppertopping,_,i,_,_),
oc(hotgreenpeppertopping,_,_,au,_),
oc(hotgreenpeppertopping,_,_,_,d),
oc(capricciosa,ar,_,_,_),
oc(capricciosa,_,ni,_,_),
oc(capricciosa,_,_,u,_),
oc(capricciosa,_,_,_,nd),
oc(anchoviestopping,r,_,_,_),
oc(anchoviestopping,_,i,_,_),
oc(anchoviestopping,_,_,au,_),
oc(anchoviestopping,_,_,_,d),
oc(quattroformaggi,r,_,_,_),
oc(quattroformaggi,_,i,_,_),
oc(quattroformaggi,_,_,nu,_),
oc(quattroformaggi,_,_,_,nd),
oc(slicedtomatotopping,ar,_,_,_),
oc(slicedtomatotopping,_,ni,_,_),
oc(slicedtomatotopping,_,_,au,_),
oc(slicedtomatotopping,_,_,_,d),
oc(veneziana,nr,_,_,_),
oc(veneziana,_,ni,_,_),
oc(veneziana,_,_,u,_),
oc(veneziana,_,_,_,nd),
oc(vegetabletopping,r,_,_,_),
oc(vegetabletopping,_,ni,_,_),
oc(vegetabletopping,_,_,u,_),
oc(vegetabletopping,_,_,_,nd),
oc(cheeseypizza,ar,_,_,_),
oc(cheeseypizza,_,i,_,_),
oc(cheeseypizza,_,_,au,_),
oc(cheeseypizza,_,_,_,nd),
oc(pinekernels,nr,_,_,_),
oc(pinekernels,_,i,_,_),
oc(pinekernels,_,_,au,_),
oc(pinekernels,_,_,_,nd),
oc(fruttidimare,r,_,_,_),
oc(fruttidimare,_,ni,_,_),
oc(fruttidimare,_,_,nu,_),
oc(fruttidimare,_,_,_,d),
oc(polloadastra,r,_,_,_),
oc(polloadastra,_,o,_,_),
oc(polloadastra,_,_,u,_),
oc(polloadastra,_,_,_,nd),
oc(pizzabase,nr,_,_,_),
oc(pizzabase,_,ni,_,_),
oc(pizzabase,_,_,u,_),
oc(pizzabase,_,_,_,nd),
oc(hot,nr,_,_,_),
oc(hot,_,i,_,_),
oc(hot,_,_,au,_),
oc(hot,_,_,_,nd),
oc(herbspicetopping,ar,_,_,_),
oc(herbspicetopping,_,ni,_,_),
oc(herbspicetopping,_,_,nu,_),
oc(herbspicetopping,_,_,_,d),
oc(americanhot,r,_,_,_),
oc(americanhot,_,i,_,_),
oc(americanhot,_,_,u,_),
oc(americanhot,_,_,_,nd),
oc(vegetarianpizzaequivalent2,nr,_,_,_),
oc(vegetarianpizzaequivalent2,_,o,_,_),
oc(vegetarianpizzaequivalent2,_,_,u,_),
oc(vegetarianpizzaequivalent2,_,_,_,nd),
oc(fruittopping,r,_,_,_),
oc(fruittopping,_,ni,_,_),
oc(fruittopping,_,_,nu,_),
oc(fruittopping,_,_,_,d),
oc(saucetopping,ar,_,_,_),
oc(saucetopping,_,ni,_,_),
oc(saucetopping,_,_,nu,_),
oc(saucetopping,_,_,_,d),
oc(domainconcept,ar,_,_,_),
oc(domainconcept,_,i,_,_),
oc(domainconcept,_,_,au,_),
oc(domainconcept,_,_,_,nd),
oc(caprina,nr,_,_,_),
oc(caprina,_,ni,_,_),
oc(caprina,_,_,nu,_),
oc(caprina,_,_,_,nd),
oc(fiorentina,nr,_,_,_),
oc(fiorentina,_,o,_,_),
oc(fiorentina,_,_,au,_),
oc(fiorentina,_,_,_,d),
oc(vegetariantopping,ar,_,_,_),
oc(vegetariantopping,_,ni,_,_),
oc(vegetariantopping,_,_,au,_),
oc(vegetariantopping,_,_,_,d),
oc(fourseasons,r,_,_,_),
oc(fourseasons,_,o,_,_),
oc(fourseasons,_,_,u,_),
oc(fourseasons,_,_,_,d),
oc(rockettopping,r,_,_,_),
oc(rockettopping,_,o,_,_),
oc(rockettopping,_,_,au,_),
oc(rockettopping,_,_,_,nd),
oc(jalapenopeppertopping,r,_,_,_),
oc(jalapenopeppertopping,_,ni,_,_),
oc(jalapenopeppertopping,_,_,au,_),
oc(jalapenopeppertopping,_,_,_,d),
oc(peppertopping,nr,_,_,_),
oc(peppertopping,_,i,_,_),
oc(peppertopping,_,_,u,_),
oc(peppertopping,_,_,_,nd),
oc(lareine,nr,_,_,_),
oc(lareine,_,i,_,_),
oc(lareine,_,_,nu,_),
oc(lareine,_,_,_,d),
oc(asparagustopping,ar,_,_,_),
oc(asparagustopping,_,i,_,_),
oc(asparagustopping,_,_,au,_),
oc(asparagustopping,_,_,_,d),
oc(parmahamtopping,r,_,_,_),
oc(parmahamtopping,_,o,_,_),
oc(parmahamtopping,_,_,nu,_),
oc(parmahamtopping,_,_,_,nd),
oc(thing,r,_,_,_),
oc(thing,_,i,_,_),
oc(thing,_,_,nu,_),
oc(thing,_,_,_,nd),
oc(spicypizza,ar,_,_,_),
oc(spicypizza,_,i,_,_),
oc(spicypizza,_,_,u,_),
oc(spicypizza,_,_,_,nd),
oc(rosa,nr,_,_,_),
oc(rosa,_,o,_,_),
oc(rosa,_,_,au,_),
oc(rosa,_,_,_,nd),
oc(giardiniera,r,_,_,_),
oc(giardiniera,_,o,_,_),
oc(giardiniera,_,_,nu,_),
oc(giardiniera,_,_,_,nd),
oc(cajun,nr,_,_,_),
oc(cajun,_,i,_,_),
oc(cajun,_,_,nu,_),
oc(cajun,_,_,_,d),
oc(goatscheesetopping,ar,_,_,_),
oc(goatscheesetopping,_,ni,_,_),
oc(goatscheesetopping,_,_,au,_),
oc(goatscheesetopping,_,_,_,d),
oc(fourcheesestopping,r,_,_,_),
oc(fourcheesestopping,_,o,_,_),
oc(fourcheesestopping,_,_,au,_),
oc(fourcheesestopping,_,_,_,d),
oc(vegetarianpizza,nr,_,_,_),
oc(vegetarianpizza,_,i,_,_),
oc(vegetarianpizza,_,_,au,_),
oc(vegetarianpizza,_,_,_,d),
oc(meatypizza,r,_,_,_),
oc(meatypizza,_,ni,_,_),
oc(meatypizza,_,_,au,_),
oc(meatypizza,_,_,_,nd),
oc(greenpeppertopping,ar,_,_,_),
oc(greenpeppertopping,_,ni,_,_),
oc(greenpeppertopping,_,_,au,_),
oc(greenpeppertopping,_,_,_,nd),
oc(oniontopping,r,_,_,_),
oc(oniontopping,_,i,_,_),
oc(oniontopping,_,_,u,_),
oc(oniontopping,_,_,_,d),
oc(valuepartition,nr,_,_,_),
oc(valuepartition,_,i,_,_),
oc(valuepartition,_,_,nu,_),
oc(valuepartition,_,_,_,nd),
oc(capertopping,nr,_,_,_),
oc(capertopping,_,ni,_,_),
oc(capertopping,_,_,nu,_),
oc(capertopping,_,_,_,nd),
oc(realitalianpizza,r,_,_,_),
oc(realitalianpizza,_,ni,_,_),
oc(realitalianpizza,_,_,nu,_),
oc(realitalianpizza,_,_,_,nd),
oc(hamtopping,nr,_,_,_),
oc(hamtopping,_,o,_,_),
oc(hamtopping,_,_,nu,_),
oc(hamtopping,_,_,_,d),
oc(redoniontopping,r,_,_,_),
oc(redoniontopping,_,ni,_,_),
oc(redoniontopping,_,_,au,_),
oc(redoniontopping,_,_,_,nd),
oc(olivetopping,r,_,_,_),
oc(olivetopping,_,i,_,_),
oc(olivetopping,_,_,au,_),
oc(olivetopping,_,_,_,nd),
oc(interestingpizza,r,_,_,_),
oc(interestingpizza,_,ni,_,_),
oc(interestingpizza,_,_,au,_),
oc(interestingpizza,_,_,_,d),
oc(cajunspicetopping,ar,_,_,_),
oc(cajunspicetopping,_,i,_,_),
oc(cajunspicetopping,_,_,u,_),
oc(cajunspicetopping,_,_,_,d),
oc(parmesantopping,nr,_,_,_),
oc(parmesantopping,_,o,_,_),
oc(parmesantopping,_,_,u,_),
oc(parmesantopping,_,_,_,d),
sub(spiciness,medium),
 sub(spiciness,mild),
 sub(spiciness,hot),
 sub(tomatotopping,slicedtomatotopping),
 sub(tomatotopping,sundriedtomatotopping),
 sub(meattopping,hotspicedbeeftopping),
 sub(meattopping,hamtopping),
 sub(meattopping,parmahamtopping),
 sub(meattopping,chickentopping),
 sub(meattopping,peperonisausagetopping),
 sub(namedpizza,quattroformaggi),
 sub(namedpizza,soho),
 sub(namedpizza,margherita),
 sub(namedpizza,sloppygiuseppe),
 sub(namedpizza,americanhot),
 sub(namedpizza,fourseasons),
 sub(namedpizza,fiorentina),
 sub(namedpizza,lareine),
 sub(namedpizza,polloadastra),
 sub(namedpizza,rosa),
 sub(namedpizza,napoletana),
 sub(namedpizza,giardiniera),
 sub(namedpizza,cajun),
 sub(namedpizza,princecarlo),
 sub(namedpizza,unclosedpizza),
 sub(namedpizza,veneziana),
 sub(namedpizza,mushroom),
 sub(namedpizza,caprina),
 sub(namedpizza,capricciosa),
 sub(namedpizza,siciliana),
 sub(namedpizza,parmense),
 sub(namedpizza,fruttidimare),
 sub(namedpizza,american),
 sub(fishtopping,anchoviestopping),
 sub(fishtopping,prawnstopping),
 sub(fishtopping,mixedseafoodtopping),
 sub(cheesetopping,cheeseyvegetabletopping),
 sub(cheesetopping,goatscheesetopping),
 sub(cheesetopping,gorgonzolatopping),
 sub(cheesetopping,parmesantopping),
 sub(cheesetopping,mozzarellatopping),
 sub(cheesetopping,fourcheesestopping),
 sub(pizza,namedpizza),
 sub(pizza,quattroformaggi),
 sub(pizza,soho),
 sub(pizza,margherita),
 sub(pizza,sloppygiuseppe),
 sub(pizza,americanhot),
 sub(pizza,fourseasons),
 sub(pizza,fiorentina),
 sub(pizza,lareine),
 sub(pizza,polloadastra),
 sub(pizza,rosa),
 sub(pizza,napoletana),
 sub(pizza,giardiniera),
 sub(pizza,cajun),
 sub(pizza,princecarlo),
 sub(pizza,unclosedpizza),
 sub(pizza,veneziana),
 sub(pizza,mushroom),
 sub(pizza,caprina),
 sub(pizza,capricciosa),
 sub(pizza,siciliana),
 sub(pizza,parmense),
 sub(pizza,fruttidimare),
 sub(pizza,american),
 sub(pizzatopping,meattopping),
 sub(pizzatopping,hotspicedbeeftopping),
 sub(pizzatopping,hamtopping),
 sub(pizzatopping,parmahamtopping),
 sub(pizzatopping,chickentopping),
 sub(pizzatopping,peperonisausagetopping),
 sub(pizzatopping,nuttopping),
 sub(pizzatopping,pinekernels),
 sub(pizzatopping,vegetabletopping),
 sub(pizzatopping,mushroomtopping),
 sub(pizzatopping,peppertopping),
 sub(pizzatopping,peperonatatopping),
 sub(pizzatopping,sweetpeppertopping),
 sub(pizzatopping,jalapenopeppertopping),
 sub(pizzatopping,greenpeppertopping),
 sub(pizzatopping,hotgreenpeppertopping),
 sub(pizzatopping,leektopping),
 sub(pizzatopping,cheeseyvegetabletopping),
 sub(pizzatopping,oniontopping),
 sub(pizzatopping,redoniontopping),
 sub(pizzatopping,tomatotopping),
 sub(pizzatopping,slicedtomatotopping),
 sub(pizzatopping,sundriedtomatotopping),
 sub(pizzatopping,asparagustopping),
 sub(pizzatopping,olivetopping),
 sub(pizzatopping,capertopping),
 sub(pizzatopping,petitpoistopping),
 sub(pizzatopping,spinachtopping),
 sub(pizzatopping,garlictopping),
 sub(pizzatopping,rockettopping),
 sub(pizzatopping,artichoketopping),
 sub(pizzatopping,cheesetopping),
 sub(pizzatopping,goatscheesetopping),
 sub(pizzatopping,gorgonzolatopping),
 sub(pizzatopping,parmesantopping),
 sub(pizzatopping,mozzarellatopping),
 sub(pizzatopping,fourcheesestopping),
 sub(pizzatopping,saucetopping),
 sub(pizzatopping,tobascopeppersauce),
 sub(pizzatopping,herbspicetopping),
 sub(pizzatopping,cajunspicetopping),
 sub(pizzatopping,rosemarytopping),
 sub(pizzatopping,fishtopping),
 sub(pizzatopping,anchoviestopping),
 sub(pizzatopping,prawnstopping),
 sub(pizzatopping,mixedseafoodtopping),
 sub(pizzatopping,fruittopping),
 sub(pizzatopping,sultanatopping),
 sub(nuttopping,pinekernels),
 sub(vegetabletopping,mushroomtopping),
 sub(vegetabletopping,peppertopping),
 sub(vegetabletopping,peperonatatopping),
 sub(vegetabletopping,sweetpeppertopping),
 sub(vegetabletopping,jalapenopeppertopping),
 sub(vegetabletopping,greenpeppertopping),
 sub(vegetabletopping,hotgreenpeppertopping),
 sub(vegetabletopping,leektopping),
 sub(vegetabletopping,cheeseyvegetabletopping),
 sub(vegetabletopping,oniontopping),
 sub(vegetabletopping,redoniontopping),
 sub(vegetabletopping,tomatotopping),
 sub(vegetabletopping,slicedtomatotopping),
 sub(vegetabletopping,sundriedtomatotopping),
 sub(vegetabletopping,asparagustopping),
 sub(vegetabletopping,olivetopping),
 sub(vegetabletopping,capertopping),
 sub(vegetabletopping,petitpoistopping),
 sub(vegetabletopping,spinachtopping),
 sub(vegetabletopping,garlictopping),
 sub(vegetabletopping,rockettopping),
 sub(vegetabletopping,artichoketopping),
 sub(pizzabase,thinandcrispybase),
 sub(pizzabase,deeppanbase),
 sub(herbspicetopping,cajunspicetopping),
 sub(herbspicetopping,rosemarytopping),
 sub(fruittopping,sultanatopping),
 sub(saucetopping,tobascopeppersauce),
 sub(domainconcept,pizzabase),
 sub(domainconcept,thinandcrispybase),
 sub(domainconcept,deeppanbase),
 sub(domainconcept,icecream),
 sub(domainconcept,pizza),
 sub(domainconcept,namedpizza),
 sub(domainconcept,quattroformaggi),
 sub(domainconcept,soho),
 sub(domainconcept,margherita),
 sub(domainconcept,sloppygiuseppe),
 sub(domainconcept,americanhot),
 sub(domainconcept,fourseasons),
 sub(domainconcept,fiorentina),
 sub(domainconcept,lareine),
 sub(domainconcept,polloadastra),
 sub(domainconcept,rosa),
 sub(domainconcept,napoletana),
 sub(domainconcept,giardiniera),
 sub(domainconcept,cajun),
 sub(domainconcept,princecarlo),
 sub(domainconcept,unclosedpizza),
 sub(domainconcept,veneziana),
 sub(domainconcept,mushroom),
 sub(domainconcept,caprina),
 sub(domainconcept,capricciosa),
 sub(domainconcept,siciliana),
 sub(domainconcept,parmense),
 sub(domainconcept,fruttidimare),
 sub(domainconcept,american),
 sub(domainconcept,pizzatopping),
 sub(domainconcept,meattopping),
 sub(domainconcept,hotspicedbeeftopping),
 sub(domainconcept,hamtopping),
 sub(domainconcept,parmahamtopping),
 sub(domainconcept,chickentopping),
 sub(domainconcept,peperonisausagetopping),
 sub(domainconcept,nuttopping),
 sub(domainconcept,pinekernels),
 sub(domainconcept,vegetabletopping),
 sub(domainconcept,mushroomtopping),
 sub(domainconcept,peppertopping),
 sub(domainconcept,peperonatatopping),
 sub(domainconcept,sweetpeppertopping),
 sub(domainconcept,jalapenopeppertopping),
 sub(domainconcept,greenpeppertopping),
 sub(domainconcept,hotgreenpeppertopping),
 sub(domainconcept,leektopping),
 sub(domainconcept,cheeseyvegetabletopping),
 sub(domainconcept,oniontopping),
 sub(domainconcept,redoniontopping),
 sub(domainconcept,tomatotopping),
 sub(domainconcept,slicedtomatotopping),
 sub(domainconcept,sundriedtomatotopping),
 sub(domainconcept,asparagustopping),
 sub(domainconcept,olivetopping),
 sub(domainconcept,capertopping),
 sub(domainconcept,petitpoistopping),
 sub(domainconcept,spinachtopping),
 sub(domainconcept,garlictopping),
 sub(domainconcept,rockettopping),
 sub(domainconcept,artichoketopping),
 sub(domainconcept,cheesetopping),
 sub(domainconcept,goatscheesetopping),
 sub(domainconcept,gorgonzolatopping),
 sub(domainconcept,parmesantopping),
 sub(domainconcept,mozzarellatopping),
 sub(domainconcept,fourcheesestopping),
 sub(domainconcept,saucetopping),
 sub(domainconcept,tobascopeppersauce),
 sub(domainconcept,herbspicetopping),
 sub(domainconcept,cajunspicetopping),
 sub(domainconcept,rosemarytopping),
 sub(domainconcept,fishtopping),
 sub(domainconcept,anchoviestopping),
 sub(domainconcept,prawnstopping),
 sub(domainconcept,mixedseafoodtopping),
 sub(domainconcept,fruittopping),
 sub(domainconcept,sultanatopping),
 sub(peppertopping,peperonatatopping),
 sub(peppertopping,sweetpeppertopping),
 sub(peppertopping,jalapenopeppertopping),
 sub(peppertopping,greenpeppertopping),
 sub(peppertopping,hotgreenpeppertopping),
 sub(greenpeppertopping,hotgreenpeppertopping),
 sub(oniontopping,redoniontopping),
 sub(valuepartition,spiciness),
 sub(valuepartition,medium),
 sub(valuepartition,mild),
 sub(valuepartition,hot),
 sub(hamtopping,parmahamtopping).



%METAPROPERTIES
% anti Rigid, anti Unit: ar, au
% Rigid, Identity, Unity, Dependence: r,i,u,d
% Non Rigid, Non Identity, Non Unity, No Dependence: nr, ni, nu, nd

%% OC predicate
%oc(Class, Rigid, Identity, Unity, Dependence)
%sub(ClassA,ClassB) when ClassA subsumes ClassB

% Transitive Closure
sub(CA,CB), sub(CB,CC) ==> sub(CA,CC).

% Sympagation Constraint
oc(Class,R,I,U,D) \ oc(Class,R,I,U,D) <=> true.
sub(CA,CB) \ sub(CA,CB) <=> true.

% Natural Propagations
oc(Class,_,o,X,Y) ==> oc(Class,r,i,X,Y).
oc(Class,ar,X,Y,Z)==> oc(Class, nr,X,Y,Z).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rules for CSP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

csp \ csp <=> true.

% Horizontal Constraints
csp \ oc(Class,r,_,_,_), oc(Class,nr,_,_,_) <=> fail.
csp \ oc(Class,_,i,_,_), oc(Class,_,ni,_,_) <=> fail.
csp \ oc(Class,_,_,u,_), oc(Class,_,_,nu,_) <=> fail.
csp \ oc(Class,_,_,_,d), oc(Class,_,_,_,nd) <=> fail.

%% New Horizontal Constraints
csp \ oc(Class,nr,_,_,_), oc(Class,_,o,_,_) <=> fail.
csp \ oc(Class,ar,_,_,_), oc(Class,_,o,_,_) <=> fail.


% Vertical Constraints
csp \ oc(ClassSuper,ar,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,nr,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,i,_,_), oc(ClassSub,_,ni,_,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,_,u,_), oc(ClassSub,_,_,nu,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,_,au,_), oc(ClassSub,_,_,u,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,_,_,d), oc(ClassSub,_,_,_,nd), sub(ClassSuper,ClassSub)<=> fail.

% Partial Labelling

% Rigidity Superclass
oc(ClassSuper,ar,_,_,_), oc(ClassSub,X,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = ar.
oc(ClassSuper,r,_,_,_), oc(ClassSub,X,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = r ; X = nr ; X = ar).
oc(ClassSuper,nr,_,_,_), oc(ClassSub,X,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nr ; X = ar).

% Rigidity Subclass
oc(ClassSuper,X,_,_,_), oc(ClassSub,ar,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = ar ; X = nr ; X = r).
oc(ClassSuper,X,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = r.
oc(ClassSuper,X,_,_,_), oc(ClassSub,nr,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nr ; X = r).

% Identity Superclass
oc(ClassSuper,_,i,_,_), oc(ClassSub,_,X,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = i ; X = o).
oc(ClassSuper,_,o,_,_), oc(ClassSub,_,X,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = o ; X = i).
oc(ClassSuper,_,ni,_,_), oc(ClassSub,_,X,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = ni ; X = o ; X = i).

% Identity Subclass
oc(ClassSuper,_,X,_,_), oc(ClassSub,_,i,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = i ; X = o ; X = ni).
oc(ClassSuper,_,X,_,_), oc(ClassSub,_,o,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = o ; X = i ; X = ni).
oc(ClassSuper,_,X,_,_), oc(ClassSub,_,ni,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = ni.

% Unity Superclass
oc(ClassSuper,_,_,au,_), oc(ClassSub,_,_,X,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = au.
oc(ClassSuper,_,_,u,_), oc(ClassSub,_,_,X,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = u.
oc(ClassSuper,_,_,nu,_), oc(ClassSub,_,_,X,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nu ; X = au ; X = u).

% Unity Subclass
oc(ClassSuper,_,_,X,_), oc(ClassSub,_,_,au,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = au ; X = nu).
oc(ClassSuper,_,_,X,_), oc(ClassSub,_,_,u,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = u ; X = nu).
oc(ClassSuper,_,_,X,_), oc(ClassSub,_,_,nu,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = nu.

% Dependence Superclass
oc(ClassSuper,_,_,_,d), oc(ClassSub,_,_,_,X), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = d.
oc(ClassSuper,_,_,_,nd), oc(ClassSub,_,_,_,X), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nd ; X = d).


% Dependence Subclass
oc(ClassSuper,_,_,_,X), oc(ClassSub,_,_,_,d), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nd ; X = d).
oc(ClassSuper,_,_,_,X), oc(ClassSub,_,_,_,nd), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = nd.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rules for pointing Violantions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Horizontal Constraints
oc(Class,r,_,_,_), oc(Class,nr,_,_,_) ==> rigidViolation(Class).
oc(Class,_,i,_,_), oc(Class,_,ni,_,_) ==> identityViolation(Class).
oc(Class,_,_,u,_), oc(Class,_,_,nu,_) ==> unityViolation(Class).
oc(Class,_,_,_,d), oc(Class,_,_,_,nd) ==> dependentViolation(Class).

%% New Horizontal Constraints
oc(Class,nr,_,_,_), oc(Class,_,o,_,_) ==> incoherentViolation(Class).
oc(Class,ar,_,_,_), oc(Class,_,o,_,_) ==> incoherentViolation(Class).


% Vertical Constraints
oc(ClassSuper,ar,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)==> antiRigidViolation(ClassSuper,ClassSub).
oc(ClassSuper,nr,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)==> noRigidViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,i,_,_), oc(ClassSub,_,ni,_,_), sub(ClassSuper,ClassSub)==> noIdentityViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,_,u,_), oc(ClassSub,_,_,nu,_), sub(ClassSuper,ClassSub)==> noUnityViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,_,au,_), oc(ClassSub,_,_,u,_), sub(ClassSuper,ClassSub)==> antiUnityViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,_,_,d), oc(ClassSub,_,_,_,nd), sub(ClassSuper,ClassSub)==> noDependentViolation(ClassSuper,ClassSub).

% Horizontal Messages

rigidViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                     atom_concat(Msg1, ' cant be Rigid and Non Rigid', FinalMsg),
                     write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

identityViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                        atom_concat(Msg1, ' cant be Sortal and Non Sortal', FinalMsg),
                        write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

unityViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                     atom_concat(Msg1, ' cant be Unity and Non Unity', FinalMsg),
                     write(FinalMsg),assert(resposta(FinalMsg)), write('\n').

dependentViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                         atom_concat(Msg1, ' cant be Dependent and Non Dependent', FinalMsg),
                         write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

incoherentViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                         atom_concat(Msg1, ' which provides its IC must be rigid', FinalMsg),
                         write(FinalMsg), assert(resposta(FinalMsg)), write('\n').
                         
% Vertical Messages

antiRigidViolation(CA,CB):- atom_concat('VIOLATION:: AntiRigid Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Rigid Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noRigidViolation(CA,CB):- atom_concat('VIOLATION:: Non Rigid Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Rigid Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noIdentityViolation(CA,CB):- atom_concat('VIOLATION:: Identiy Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Non Identity Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noUnityViolation(CA,CB):- atom_concat('VIOLATION:: Unity Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Non Unity Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

antiUnityViolation(CA,CB):- atom_concat('VIOLATION:: Anti Unity Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Unity Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noDependentViolation(CA,CB):- atom_concat('VIOLATION:: Dependent Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Non Dependent Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').



%METAPROPERTIES
% anti Rigid, anti Unit: ar, au
% Rigid, Identity, Unity, Dependence: r,i,u,d
% Non Rigid, Non Identity, Non Unity, No Dependence: nr, ni, nu, nd












