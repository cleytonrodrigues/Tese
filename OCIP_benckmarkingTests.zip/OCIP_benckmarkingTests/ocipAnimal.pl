% Autor:
% Data:

:- module(ocip,[oc/5, sub/2, facts/0, resposta/1]).
:- use_module(library(chr)).

:- chr_constraint oc/5, sub/2, facts/0, csp/0.

:- dynamic resposta/1.




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BANNER                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- nl.
:- format("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n",[]).
:- format("%                    __   __     __                             %\n",[]).
:- format("%                   |  | |    | |__|                            %\n",[]).
:- format("%                   |__| |__  | |     Version 2.0               %\n",[]).
:- format("%                                                               %\n",[]).
:- format("%            OntoClean Implementation in Prolog                 %\n",[]).
:- format("% OCIP version 1.0, Copyright (C) 2016                          %\n",[]).
:- format("% This is free software, and you are welcome to redistribute it.%\n",[]).
:- format("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n\n",[]).

%facts <=> oc(agente,ar,ni,nu,d), oc(organizacao,r,o, u,d), oc(pessoaNatural,r,o, u,nd),
%           oc(pessoaPassiva,ar,i, u,d),oc(pessoaAtiva,ar,i, u,d),
%           oc(pessoaImputavel,ar,i, u,nd),oc(pessoaInimputavel,nr,i, u,nd), sub(agente,organizacao),
%           sub(agente,pessoaNatural), sub(pessoaNatural,pessoaPassiva),
%           sub(pessoaNatural,pessoaAtiva),sub(pessoaNatural,pessoaImputavel),sub(pessoaNatural,pessoaInimputavel),
%           oc(comportamento,r,o,u,d), oc(involuntario,r,i,u,d), oc(voluntario,r,i,u,d),
%           sub(comportamento,involuntario),sub(comportamento,voluntario),
%           oc(conduta,r,i,u,d), oc(acao,r,i,u,d), oc(omissao,r,i,u,d),
%           oc(condutaPermitida,nr,i,u,d),oc(condutaProibida,nr,i,u,d),
%           oc(condutaComCulpabilidade,nr,i,u,d),  oc(condutaComPericulosidade,nr,i,u,d),oc(condutaConflitante,nr,i,u,d),
%           oc(conflitoDeontico,nr,i,u,d),oc(infracaoPenal,nr,i,u,d),
%           oc(Contravencao,nr,i,u,d), oc(Crime,nr,i,u,d),
%           sub(voluntario,conduta), sub(conduta,acao), sub(conduta,omissao),
%           sub(conduta,condutaPermitida),sub(conduta,condutaProibida), sub(condutaPermitida,conflitoDeontico),
%           sub(condutaProibida,condutaComCulpabilidade),  sub(condutaProibida,condutaComPericulosidade),
%           sub(condutaProibida,condutaConflitante), sub(condutaProibida,conflitoDeontico),
%           sub(condutaProibida,infracaoPenal), sub(infracaoPenal,Contravencao), sub(infracaoPenal,Crime).

%facts <=> oc(agente,r,ni,nu,nd), oc(organizacao,r,o, u,nd), oc(pessoaNatural,r,o, u,nd),
%           oc(pessoaPassiva,ar,i, u,d), oc(pessoaViva,r,i, u,nd),oc(pessoaAtiva,ar,i, u,d),
%           oc(pessoaImputavel,ar,i, u,nd),oc(pessoaInimputavel,nr,i, u,nd), sub(agente,organizacao),
%           sub(agente,pessoaNatural), sub(pessoaNatural,pessoaPassiva),sub(pessoaNatural,pessoaViva),
%           sub(pessoaViva,pessoaAtiva),sub(pessoaViva,pessoaImputavel),sub(pessoaViva,pessoaInimputavel),
%           oc(comportamento,r,o,nu,d), oc(involuntario,r,i,nu,d), oc(voluntario,r,i,nu,d),
%           sub(comportamento,involuntario),sub(comportamento,voluntario),
%           oc(conduta,r,i,nu,d), oc(acao,nr,ni,u,nd), oc(omissao,r,ni,nu,d),
%           oc(condutaPermitida,nr,i,nu,d),oc(condutaProibida,nr,i,nu,d),
%           oc(condutaComCulpabilidade,nr,i,nu,d),  oc(condutaComPericulosidade,nr,i,nu,d),oc(condutaConflitante,nr,i,nu,d),
%           oc(conflitoDeontico,nr,i,nu,d),oc(infracaoPenal,nr,i,nu,d),
%           oc(Contravencao,nr,i,nu,d), oc(Crime,nr,i,nu,d),
%           sub(voluntario,conduta), sub(conduta,acao), sub(conduta,omissao),
%           sub(conduta,condutaPermitida),sub(conduta,condutaProibida), sub(condutaPermitida,conflitoDeontico),
%           sub(condutaProibida,condutaComCulpabilidade),  sub(condutaProibida,condutaComPericulosidade),
%           sub(condutaProibida,condutaConflitante), sub(condutaProibida,conflitoDeontico),
%           sub(condutaProibida,infracaoPenal), sub(infracaoPenal,Contravencao), sub(infracaoPenal,Crime).

%facts<=>   oc(entity,r,ni,nu,nd), oc(location,r,o,au,nd),oc(matter,r,o,au,nd), oc(red,nr,ni,nu,nd), oc(agent,ar,ni,nu,d), oc(group,r,o,au,nd),
%            oc(physicalObject,r,o,u,nd), oc(livingBeing,r,o,u,nd), oc(groupPeople,r,i,au,nd), oc(fruit,r,o,u,nd), oc(food,ar,i,au,d),
%            oc(animal,r,o,u,nd), oc(socialEntity,r,ni,u,nd), oc(legalAgent,ar,i,nu,d), oc(apple,r,o,u,nd), oc(country,ar,i,u,nd),
%            oc(redApple,ar,i,u,nd), oc(caterpillar,ar,i,u,nd), oc(butterfly,ar,i,u,nd), oc(vertebrate,r,i,u,nd), oc(organization,r,o,u,nd),
%            oc(person,r,o,u,nd), sub(entity, location), sub(entity, matter), sub(entity,red), sub(entity,agent),
%            sub(entity, group), sub(location,country), sub(matter,physicalObject), sub(matter,food), sub(matter,livingBeing),
%            sub(entity, livingBeing), sub(physicalObject, fruit), sub(physicalObject,animal), sub(red,redApple),
%            sub(agent, animal), sub(agent, legalAgent), sub(agent,socialEntity), sub(livingBeing, animal),
%            sub(group,groupPeople), sub(groupPeople,socialEntity), sub(groupPeople,organization), sub(fruit, apple),
%            sub(food, apple), sub(food, caterpillar), sub(apple, redApple), sub(socialEntity, organization),
%            sub(legalAgent, organization), sub(legalAgent, person), sub(legalAgent, country), sub(animal, caterpillar),
%            sub(animal, butterfly), sub(animal, vertebrate), sub(vertebrate, person).

%facts<=>   oc(entity,r,ni,nu,nd), oc(location,r,o,nu,nd),oc(matter,r,o,au,nd), oc(group,r,o,au,nd),
%            oc(physicalObject,r,o,u,nd), oc(livingBeing,r,o,u,nd), oc(groupPeople,r,i,au,nd), oc(fruit,r,o,u,nd),
%            oc(animal,r,o,u,nd), oc(socialEntity,r,ni,u,nd), oc(apple,r,o,u,nd), oc(country,r,o,u,d),
%            oc(region,r,i,nu,nd), oc(lepidopteran,r,o,u,nd), oc(caterpillar,ar,i,u,nd), oc(butterfly,ar,i,u,nd),
%            oc(vertebrate,r,i,u,nd), oc(organization,r,o,u,nd), oc(person,r,o,u,nd),
%            sub(entity, location), sub(entity, matter), sub(entity, physicalObject), sub(entity, livingBeing),
%            sub(entity,socialEntity), sub(entity, group), sub(location,region), sub(physicalObject, fruit),
%            sub(fruit, apple), sub(livingBeing, animal), sub(animal, lepidopteran), sub(animal, vertebrate),
%            sub(lepidopteran, caterpillar), sub(lepidopteran, butterfly), sub(vertebrate, person),
%            sub(socialEntity, organization), sub(socialEntity, country), sub(group,groupPeople).

%facts<=>   oc(entity,r,ni,nu,nd), oc(location,r,o,nu,nd),oc(matter,r,o,au,nd), oc(group,r,o,au,nd),
%            oc(physicalObject,r,o,u,nd), oc(livingBeing,r,o,u,nd), oc(groupPeople,r,i,au,nd), oc(fruit,r, i, u, nd),
%            oc(animal,AR,AI,AU,AD), oc(socialEntity,r,ni,u,nd), oc(apple,r,o,u,nd), oc(country,r,o,u,d),
%            oc(region,r,i,nu,nd), oc(lepidopteran,r,o,u,nd), oc(caterpillar,ar,i,u,nd), oc(butterfly,ar,i,u,nd),
%            oc(vertebrate,VR,VI,VU,VD), oc(organization,r,o,u,nd), oc(person,r,o,u,nd),
%            sub(entity, location), sub(entity, matter), sub(entity, physicalObject), sub(entity, livingBeing),
%            sub(entity,socialEntity), sub(entity, group), sub(location,region), sub(physicalObject, fruit),
%            sub(fruit, apple), sub(livingBeing, animal), sub(animal, lepidopteran), sub(animal, vertebrate),
%            sub(lepidopteran, caterpillar), sub(lepidopteran, butterfly), sub(vertebrate, person),
%            sub(socialEntity, organization), sub(socialEntity, country), sub(group,groupPeople).

facts <=> oc(value,nr,_,_,_),
oc(value,_,o,_,_),
oc(value,_,_,au,_),
oc(value,_,_,_,d),
oc(safe,r,_,_,_),
oc(safe,_,i,_,_),
oc(safe,_,_,au,_),
oc(safe,_,_,_,nd),
oc(risky,r,_,_,_),
oc(risky,_,o,_,_),
oc(risky,_,_,u,_),
oc(risky,_,_,_,d),
oc(mammal,nr,_,_,_),
oc(mammal,_,o,_,_),
oc(mammal,_,_,nu,_),
oc(mammal,_,_,_,nd),
oc(calf,nr,_,_,_),
oc(calf,_,i,_,_),
oc(calf,_,_,nu,_),
oc(calf,_,_,_,nd),
oc(child_value,r,_,_,_),
oc(child_value,_,o,_,_),
oc(child_value,_,_,u,_),
oc(child_value,_,_,_,nd),
oc(crocadilian,nr,_,_,_),
oc(crocadilian,_,ni,_,_),
oc(crocadilian,_,_,au,_),
oc(crocadilian,_,_,_,nd),
oc(tree,nr,_,_,_),
oc(tree,_,ni,_,_),
oc(tree,_,_,u,_),
oc(tree,_,_,_,d),
oc(lioness,nr,_,_,_),
oc(lioness,_,o,_,_),
oc(lioness,_,_,u,_),
oc(lioness,_,_,_,nd),
oc(lion,nr,_,_,_),
oc(lion,_,i,_,_),
oc(lion,_,_,u,_),
oc(lion,_,_,_,d),
oc(reptile,ar,_,_,_),
oc(reptile,_,o,_,_),
oc(reptile,_,_,nu,_),
oc(reptile,_,_,_,d),
oc(dangerous,nr,_,_,_),
oc(dangerous,_,o,_,_),
oc(dangerous,_,_,nu,_),
oc(dangerous,_,_,_,d),
oc(domestication,r,_,_,_),
oc(domestication,_,ni,_,_),
oc(domestication,_,_,u,_),
oc(domestication,_,_,_,d),
oc(lizard,ar,_,_,_),
oc(lizard,_,i,_,_),
oc(lizard,_,_,nu,_),
oc(lizard,_,_,_,d),
oc(adult_value,nr,_,_,_),
oc(adult_value,_,ni,_,_),
oc(adult_value,_,_,nu,_),
oc(adult_value,_,_,_,nd),
oc(omnivore,nr,_,_,_),
oc(omnivore,_,o,_,_),
oc(omnivore,_,_,nu,_),
oc(omnivore,_,_,_,nd),
oc(carp,ar,_,_,_),
oc(carp,_,i,_,_),
oc(carp,_,_,au,_),
oc(carp,_,_,_,d),
oc(living_thing,r,_,_,_),
oc(living_thing,_,i,_,_),
oc(living_thing,_,_,au,_),
oc(living_thing,_,_,_,d),
oc(animal,nr,_,_,_),
oc(animal,_,i,_,_),
oc(animal,_,_,nu,_),
oc(animal,_,_,_,nd),
oc(herbivore,r,_,_,_),
oc(herbivore,_,i,_,_),
oc(herbivore,_,_,nu,_),
oc(herbivore,_,_,_,nd),
oc(cow,r,_,_,_),
oc(cow,_,i,_,_),
oc(cow,_,_,au,_),
oc(cow,_,_,_,d),
oc(dangerousness,nr,_,_,_),
oc(dangerousness,_,ni,_,_),
oc(dangerousness,_,_,au,_),
oc(dangerousness,_,_,_,d),
oc(plant,nr,_,_,_),
oc(plant,_,i,_,_),
oc(plant,_,_,au,_),
oc(plant,_,_,_,nd),
oc(domestic_value,r,_,_,_),
oc(domestic_value,_,i,_,_),
oc(domestic_value,_,_,au,_),
oc(domestic_value,_,_,_,d),
oc(pig,r,_,_,_),
oc(pig,_,o,_,_),
oc(pig,_,_,au,_),
oc(pig,_,_,_,nd),
oc(infant_value,nr,_,_,_),
oc(infant_value,_,i,_,_),
oc(infant_value,_,_,au,_),
oc(infant_value,_,_,_,d),
oc(fish,ar,_,_,_),
oc(fish,_,o,_,_),
oc(fish,_,_,au,_),
oc(fish,_,_,_,nd),
oc(cat,r,_,_,_),
oc(cat,_,i,_,_),
oc(cat,_,_,u,_),
oc(cat,_,_,_,nd),
oc(quality,r,_,_,_),
oc(quality,_,ni,_,_),
oc(quality,_,_,au,_),
oc(quality,_,_,_,d),
oc(feral_value,ar,_,_,_),
oc(feral_value,_,i,_,_),
oc(feral_value,_,_,au,_),
oc(feral_value,_,_,_,d),
oc(carnivore,r,_,_,_),
oc(carnivore,_,ni,_,_),
oc(carnivore,_,_,u,_),
oc(carnivore,_,_,_,nd),
oc(grass,nr,_,_,_),
oc(grass,_,i,_,_),
oc(grass,_,_,u,_),
oc(grass,_,_,_,d),
oc(todler_value,nr,_,_,_),
oc(todler_value,_,ni,_,_),
oc(todler_value,_,_,nu,_),
oc(todler_value,_,_,_,d),
oc(valuepartition,nr,_,_,_),
oc(valuepartition,_,i,_,_),
oc(valuepartition,_,_,u,_),
oc(valuepartition,_,_,_,d),
oc(domain_entity,nr,_,_,_),
oc(domain_entity,_,o,_,_),
oc(domain_entity,_,_,nu,_),
oc(domain_entity,_,_,_,nd),
oc(heiffer,nr,_,_,_),
oc(heiffer,_,i,_,_),
oc(heiffer,_,_,au,_),
oc(heiffer,_,_,_,d),
oc(piglet,ar,_,_,_),
oc(piglet,_,ni,_,_),
oc(piglet,_,_,nu,_),
oc(piglet,_,_,_,d),
oc(leafy_plant,r,_,_,_),
oc(leafy_plant,_,ni,_,_),
oc(leafy_plant,_,_,u,_),
oc(leafy_plant,_,_,_,d),
oc(age_group,nr,_,_,_),
oc(age_group,_,i,_,_),
oc(age_group,_,_,u,_),
oc(age_group,_,_,_,d),
oc(elderly_value,nr,_,_,_),
oc(elderly_value,_,i,_,_),
oc(elderly_value,_,_,au,_),
oc(elderly_value,_,_,_,d),
oc(goldfish,r,_,_,_),
oc(goldfish,_,ni,_,_),
oc(goldfish,_,_,u,_),
oc(goldfish,_,_,_,nd),
oc(sex_value,nr,_,_,_),
oc(sex_value,_,ni,_,_),
oc(sex_value,_,_,nu,_),
oc(sex_value,_,_,_,nd),
oc(person,ar,_,_,_),
oc(person,_,o,_,_),
oc(person,_,_,u,_),
oc(person,_,_,_,d),
oc(bull,nr,_,_,_),
oc(bull,_,i,_,_),
oc(bull,_,_,au,_),
oc(bull,_,_,_,nd),
oc(pal_constraint,ar,_,_,_),
oc(pal_constraint,_,o,_,_),
oc(pal_constraint,_,_,u,_),
oc(pal_constraint,_,_,_,d),
oc(wild_value,nr,_,_,_),
oc(wild_value,_,ni,_,_),
oc(wild_value,_,_,au,_),
oc(wild_value,_,_,_,nd),
oc(male_animal,nr,_,_,_),
oc(male_animal,_,i,_,_),
oc(male_animal,_,_,au,_),
oc(male_animal,_,_,_,d),
oc(dangerous_animal,r,_,_,_),
oc(dangerous_animal,_,ni,_,_),
oc(dangerous_animal,_,_,u,_),
oc(dangerous_animal,_,_,_,nd),
oc(directed_binary_relation,nr,_,_,_),
oc(directed_binary_relation,_,o,_,_),
oc(directed_binary_relation,_,_,au,_),
oc(directed_binary_relation,_,_,_,nd),
oc(risk,ar,_,_,_),
oc(risk,_,i,_,_),
oc(risk,_,_,nu,_),
oc(risk,_,_,_,d),
oc(bird,nr,_,_,_),
oc(bird,_,i,_,_),
oc(bird,_,_,au,_),
oc(bird,_,_,_,d),
oc(female_animal,nr,_,_,_),
oc(female_animal,_,ni,_,_),
oc(female_animal,_,_,u,_),
oc(female_animal,_,_,_,d),
oc(domestic_cat,nr,_,_,_),
oc(domestic_cat,_,i,_,_),
oc(domestic_cat,_,_,au,_),
oc(domestic_cat,_,_,_,nd),
 sub(value,sex_value),
 sub(mammal,pig),
 sub(mammal,cat),
 sub(mammal,domestic_cat),
 sub(mammal,lion),
 sub(mammal,cow),
 sub(mammal,person),
 sub(child_value,infant_value),
 sub(child_value,todler_value),
 sub(reptile,crocadilian),
 sub(reptile,lizard),
 sub(domestication,feral_value),
 sub(domestication,wild_value),
 sub(domestication,domestic_value),
 sub(adult_value,elderly_value),
 sub(carp,goldfish),
 sub(living_thing,animal),
 sub(living_thing,bird),
 sub(living_thing,mammal),
 sub(living_thing,pig),
 sub(living_thing,cat),
 sub(living_thing,domestic_cat),
 sub(living_thing,lion),
 sub(living_thing,cow),
 sub(living_thing,person),
 sub(living_thing,reptile),
 sub(living_thing,crocadilian),
 sub(living_thing,lizard),
 sub(living_thing,fish),
 sub(living_thing,carp),
 sub(living_thing,goldfish),
 sub(living_thing,plant),
 sub(living_thing,tree),
 sub(living_thing,grass),
 sub(living_thing,leafy_plant),
 sub(animal,bird),
 sub(animal,mammal),
 sub(animal,pig),
 sub(animal,cat),
 sub(animal,domestic_cat),
 sub(animal,lion),
 sub(animal,cow),
 sub(animal,person),
 sub(animal,reptile),
 sub(animal,crocadilian),
 sub(animal,lizard),
 sub(animal,fish),
 sub(animal,carp),
 sub(animal,goldfish),
 sub(dangerousness,safe),
 sub(dangerousness,dangerous),
 sub(dangerousness,risky),
 sub(plant,tree),
 sub(plant,grass),
 sub(plant,leafy_plant),
 sub(fish,carp),
 sub(fish,goldfish),
 sub(cat,domestic_cat),
 sub(cat,lion),
 sub(quality,risk),
 sub(valuepartition,dangerousness),
 sub(valuepartition,safe),
 sub(valuepartition,dangerous),
 sub(valuepartition,risky),
 sub(valuepartition,age_group),
 sub(valuepartition,adult_value),
 sub(valuepartition,elderly_value),
 sub(valuepartition,child_value),
 sub(valuepartition,infant_value),
 sub(valuepartition,todler_value),
 sub(valuepartition,domestication),
 sub(valuepartition,feral_value),
 sub(valuepartition,wild_value),
 sub(valuepartition,domestic_value),
 sub(domain_entity,value),
 sub(domain_entity,sex_value),
 sub(domain_entity,living_thing),
 sub(domain_entity,animal),
 sub(domain_entity,bird),
 sub(domain_entity,mammal),
 sub(domain_entity,pig),
 sub(domain_entity,cat),
 sub(domain_entity,domestic_cat),
 sub(domain_entity,lion),
 sub(domain_entity,cow),
 sub(domain_entity,person),
 sub(domain_entity,reptile),
 sub(domain_entity,crocadilian),
 sub(domain_entity,lizard),
 sub(domain_entity,fish),
 sub(domain_entity,carp),
 sub(domain_entity,goldfish),
 sub(domain_entity,plant),
 sub(domain_entity,tree),
 sub(domain_entity,grass),
 sub(domain_entity,leafy_plant),
 sub(domain_entity,valuepartition),
 sub(domain_entity,dangerousness),
 sub(domain_entity,safe),
 sub(domain_entity,dangerous),
 sub(domain_entity,risky),
 sub(domain_entity,age_group),
 sub(domain_entity,adult_value),
 sub(domain_entity,elderly_value),
 sub(domain_entity,child_value),
 sub(domain_entity,infant_value),
 sub(domain_entity,todler_value),
 sub(domain_entity,domestication),
 sub(domain_entity,feral_value),
 sub(domain_entity,wild_value),
 sub(domain_entity,domestic_value),
 sub(domain_entity,quality),
 sub(domain_entity,risk),
 sub(age_group,adult_value),
 sub(age_group,elderly_value),
 sub(age_group,child_value),
 sub(age_group,infant_value),
 sub(age_group,todler_value).



%METAPROPERTIES
% anti Rigid, anti Unit: ar, au
% Rigid, Identity, Unity, Dependence: r,i,u,d
% Non Rigid, Non Identity, Non Unity, No Dependence: nr, ni, nu, nd

%% OC predicate
%oc(Class, Rigid, Identity, Unity, Dependence)
%sub(ClassA,ClassB) when ClassA subsumes ClassB

% Transitive Closure
sub(CA,CB), sub(CB,CC) ==> sub(CA,CC).

% Sympagation Constraint
oc(Class,R,I,U,D) \ oc(Class,R,I,U,D) <=> true.
sub(CA,CB) \ sub(CA,CB) <=> true.

% Natural Propagations
oc(Class,_,o,X,Y) ==> oc(Class,r,i,X,Y).
oc(Class,ar,X,Y,Z)==> oc(Class, nr,X,Y,Z).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rules for CSP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

csp \ csp <=> true.

% Horizontal Constraints
csp \ oc(Class,r,_,_,_), oc(Class,nr,_,_,_) <=> fail.
csp \ oc(Class,_,i,_,_), oc(Class,_,ni,_,_) <=> fail.
csp \ oc(Class,_,_,u,_), oc(Class,_,_,nu,_) <=> fail.
csp \ oc(Class,_,_,_,d), oc(Class,_,_,_,nd) <=> fail.

%% New Horizontal Constraints
csp \ oc(Class,nr,_,_,_), oc(Class,_,o,_,_) <=> fail.
csp \ oc(Class,ar,_,_,_), oc(Class,_,o,_,_) <=> fail.


% Vertical Constraints
csp \ oc(ClassSuper,ar,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,nr,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,i,_,_), oc(ClassSub,_,ni,_,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,_,u,_), oc(ClassSub,_,_,nu,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,_,au,_), oc(ClassSub,_,_,u,_), sub(ClassSuper,ClassSub)<=> fail.
csp \ oc(ClassSuper,_,_,_,d), oc(ClassSub,_,_,_,nd), sub(ClassSuper,ClassSub)<=> fail.

% Partial Labelling

% Rigidity Superclass
oc(ClassSuper,ar,_,_,_), oc(ClassSub,X,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = ar.
oc(ClassSuper,r,_,_,_), oc(ClassSub,X,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = r ; X = nr ; X = ar).
oc(ClassSuper,nr,_,_,_), oc(ClassSub,X,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nr ; X = ar).

% Rigidity Subclass
oc(ClassSuper,X,_,_,_), oc(ClassSub,ar,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = ar ; X = nr ; X = r).
oc(ClassSuper,X,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = r.
oc(ClassSuper,X,_,_,_), oc(ClassSub,nr,_,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nr ; X = r).

% Identity Superclass
oc(ClassSuper,_,i,_,_), oc(ClassSub,_,X,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = i ; X = o).
oc(ClassSuper,_,o,_,_), oc(ClassSub,_,X,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = o ; X = i).
oc(ClassSuper,_,ni,_,_), oc(ClassSub,_,X,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = ni ; X = o ; X = i).

% Identity Subclass
oc(ClassSuper,_,X,_,_), oc(ClassSub,_,i,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = i ; X = o ; X = ni).
oc(ClassSuper,_,X,_,_), oc(ClassSub,_,o,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = o ; X = i ; X = ni).
oc(ClassSuper,_,X,_,_), oc(ClassSub,_,ni,_,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = ni.

% Unity Superclass
oc(ClassSuper,_,_,au,_), oc(ClassSub,_,_,X,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = au.
oc(ClassSuper,_,_,u,_), oc(ClassSub,_,_,X,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = u.
oc(ClassSuper,_,_,nu,_), oc(ClassSub,_,_,X,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nu ; X = au ; X = u).

% Unity Subclass
oc(ClassSuper,_,_,X,_), oc(ClassSub,_,_,au,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = au ; X = nu).
oc(ClassSuper,_,_,X,_), oc(ClassSub,_,_,u,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = u ; X = nu).
oc(ClassSuper,_,_,X,_), oc(ClassSub,_,_,nu,_), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = nu.

% Dependence Superclass
oc(ClassSuper,_,_,_,d), oc(ClassSub,_,_,_,X), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = d.
oc(ClassSuper,_,_,_,nd), oc(ClassSub,_,_,_,X), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nd ; X = d).


% Dependence Subclass
oc(ClassSuper,_,_,_,X), oc(ClassSub,_,_,_,d), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, (X = nd ; X = d).
oc(ClassSuper,_,_,_,X), oc(ClassSub,_,_,_,nd), sub(ClassSuper,ClassSub)==> \+ ground(X) | csp, X = nd.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rules for pointing Violantions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Horizontal Constraints
oc(Class,r,_,_,_), oc(Class,nr,_,_,_) ==> rigidViolation(Class).
oc(Class,_,i,_,_), oc(Class,_,ni,_,_) ==> identityViolation(Class).
oc(Class,_,_,u,_), oc(Class,_,_,nu,_) ==> unityViolation(Class).
oc(Class,_,_,_,d), oc(Class,_,_,_,nd) ==> dependentViolation(Class).

%% New Horizontal Constraints
oc(Class,nr,_,_,_), oc(Class,_,o,_,_) ==> incoherentViolation(Class).
oc(Class,ar,_,_,_), oc(Class,_,o,_,_) ==> incoherentViolation(Class).


% Vertical Constraints
oc(ClassSuper,ar,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)==> antiRigidViolation(ClassSuper,ClassSub).
oc(ClassSuper,nr,_,_,_), oc(ClassSub,r,_,_,_), sub(ClassSuper,ClassSub)==> noRigidViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,i,_,_), oc(ClassSub,_,ni,_,_), sub(ClassSuper,ClassSub)==> noIdentityViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,_,u,_), oc(ClassSub,_,_,nu,_), sub(ClassSuper,ClassSub)==> noUnityViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,_,au,_), oc(ClassSub,_,_,u,_), sub(ClassSuper,ClassSub)==> antiUnityViolation(ClassSuper,ClassSub).
oc(ClassSuper,_,_,_,d), oc(ClassSub,_,_,_,nd), sub(ClassSuper,ClassSub)==> noDependentViolation(ClassSuper,ClassSub).

% Horizontal Messages

rigidViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                     atom_concat(Msg1, ' cant be Rigid and Non Rigid', FinalMsg),
                     write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

identityViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                        atom_concat(Msg1, ' cant be Sortal and Non Sortal', FinalMsg),
                        write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

unityViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                     atom_concat(Msg1, ' cant be Unity and Non Unity', FinalMsg),
                     write(FinalMsg),assert(resposta(FinalMsg)), write('\n').

dependentViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                         atom_concat(Msg1, ' cant be Dependent and Non Dependent', FinalMsg),
                         write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

incoherentViolation(CA):- atom_concat('VIOLATION:: Class ', CA, Msg1),
                         atom_concat(Msg1, ' which provides its IC must be rigid', FinalMsg),
                         write(FinalMsg), assert(resposta(FinalMsg)), write('\n').
                         
% Vertical Messages

antiRigidViolation(CA,CB):- atom_concat('VIOLATION:: AntiRigid Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Rigid Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noRigidViolation(CA,CB):- atom_concat('VIOLATION:: Non Rigid Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Rigid Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noIdentityViolation(CA,CB):- atom_concat('VIOLATION:: Identiy Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Non Identity Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noUnityViolation(CA,CB):- atom_concat('VIOLATION:: Unity Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Non Unity Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

antiUnityViolation(CA,CB):- atom_concat('VIOLATION:: Anti Unity Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Unity Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').

noDependentViolation(CA,CB):- atom_concat('VIOLATION:: Dependent Class ', CA, Msg1),
                            atom_concat(Msg1,' cant subsume ', Msg2),
	                    atom_concat(Msg2,' Non Dependent Class ', Msg3),
	                    atom_concat(Msg3, CB, FinalMsg),
			    write(FinalMsg), assert(resposta(FinalMsg)), write('\n').



%METAPROPERTIES
% anti Rigid, anti Unit: ar, au
% Rigid, Identity, Unity, Dependence: r,i,u,d
% Non Rigid, Non Identity, Non Unity, No Dependence: nr, ni, nu, nd












